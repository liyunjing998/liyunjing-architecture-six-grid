# 第三方依赖

网页随包包含 Three.js 0.170.0 的必要模块（渲染器、OrbitControls、GLTF／OBJ／STL 导入、GLTF 导出、BufferGeometryUtils）及其附带的 fflate 模块。

Three.js 为 MIT License，完整许可证位于 `assets/web/vendor/three/LICENSE`。fflate 0.8.2 的 MIT 版权与许可全文保存在 `assets/web/vendor/fflate-LICENSE`，原文件头声明也已保留。许可证来源：https://raw.githubusercontent.com/101arrowz/fflate/v0.8.2/LICENSE 。再分发时保留这些声明。

此说明不替用户决定其导入模型、材质或图片的传播权利。随包教学模型是本次生成的简单几何，不含原项目资产。
