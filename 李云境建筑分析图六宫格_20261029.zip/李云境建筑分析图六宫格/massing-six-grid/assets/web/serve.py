"""Loopback-only static server and bounded artifact saver for analysis mode."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import argparse, json, base64, re, hashlib

ROOT = Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw): super().__init__(*a,directory=str(ROOT),**kw)
    def do_GET(self):
        if self.path == '/health':
            self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps({'app':'analysis-mode','version':'1.0.0','root':str(ROOT)}).encode());return
        super().do_GET()
    def do_POST(self):
        if self.path != '/api/save': self.send_error(404);return
        origin = self.headers.get('Origin')
        if origin and urlparse(origin).netloc != self.headers.get('Host'): self.send_error(403);return
        size = int(self.headers.get('Content-Length','0'))
        if size<=0 or size>180*1024*1024:self.send_error(413);return
        try:
            data=json.loads(self.rfile.read(size));name=data['name']
            if name != Path(name).name or name.startswith('.') or not re.fullmatch(r'[\w\-\u4e00-\u9fff. ]{1,150}',name):raise ValueError('Invalid filename')
            if Path(name).suffix.lower() not in ['.png','.svg','.json','.zip','.webm','.mp4','.md','.txt','.glb']:raise ValueError('Unsupported output')
            content=base64.b64decode(data['base64'],validate=True)
            folder=ROOT/'exports';folder.mkdir(exist_ok=True);dest=folder/name
            if dest.exists():
                if dest.read_bytes()!=content:
                    stamp=__import__('datetime').datetime.now().strftime('%Y%m%d-%H%M%S-%f')
                    dest=folder/(dest.stem+'_'+stamp+dest.suffix)
            dest.write_bytes(content)
            result=json.dumps({'saved':True,'name':dest.name,'path':str(dest),'url':'exports/'+dest.name,'sha256':hashlib.sha256(content).hexdigest()},ensure_ascii=False).encode()
            self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.end_headers();self.wfile.write(result)
        except Exception as e:self.send_error(400,str(e))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8781);a=p.parse_args()
    print(f'分析图模式 http://127.0.0.1:{a.port}',flush=True)
    ThreadingHTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
