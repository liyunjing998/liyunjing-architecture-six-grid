import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {OBJLoader} from 'three/addons/loaders/OBJLoader.js';
import {STLLoader} from 'three/addons/loaders/STLLoader.js';
import {zipSync,strToU8} from 'three/addons/libs/fflate.module.js';
import {buildGrid,findPath} from './navigation.js';
import {simplifyGridRoute,levelLift} from './route_geometry.js';
import {createMassingSession} from './massing_variants.js?v=massing-editor-v03';
import {FLOW_PAGES,FLOW_TYPES,inferFlowType,flowMatchesPage,routesAfterPageClear,shouldAutoGenerateFlow} from './flow_taxonomy.js';

const $=id=>document.getElementById(id), canvas=$('scene'),viewport=$('viewport');
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,preserveDrawingBuffer:true,alpha:false});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.setClearColor(0xf8f8f4);renderer.localClippingEnabled=true;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.88;
const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-40,40,35,-35,.1,2500);camera.up.set(0,0,1);
const controls=new OrbitControls(camera,canvas);controls.enableDamping=false;controls.minPolarAngle=.02;controls.maxPolarAngle=Math.PI*.49;
scene.add(new THREE.AmbientLight(0xffffff,1.7));const sun=new THREE.DirectionalLight(0xffffff,2.3);sun.position.set(-40,-60,100);scene.add(sun);const fill=new THREE.DirectionalLight(0xd9e4e5,.8);fill.position.set(50,80,40);scene.add(fill);
const modelRoot=new THREE.Group(),routesRoot=new THREE.Group(),massingRoot=new THREE.Group();scene.add(modelRoot,routesRoot,massingRoot);
const planeTop=new THREE.Plane(new THREE.Vector3(0,0,-1),10000),planeBottom=new THREE.Plane(new THREE.Vector3(0,0,1),10000);
const colorPalette=['#cf493b','#2f7891','#ba8839','#5f8a6d','#9b668a'];
let data=null,modelMeshes=[],navMeshes=[],routes=[],selected=null,mode='flow',style='white',cameraMode='iso',stepIndex=0;
let flowPage='work',flowAutoGenerateSuppressed=false;
let busy=false,drawMode=null,pickPoints=[],navCache=new Map(),evolving=false,evolutionStart=0,evolutionRaf=0,routeMotion=0,lastMotion=0;
let liveViews=[],liveRenderer=null,liveRaf=0,liveSync=true,liveActive=0,liveChanging=false;
let massingGroups=[],massingImages=[],massingSession=null,savedMassingChoices=null,candidateRounds={},shownCandidates=[],candidateIndex=null,thumbDirty=true,geometryRevision=0,explodeLevels=[];
let pendingPublication=null,publicationRevision=null;
let editEnabled=false,editPartId=null,editAxis=2,editSide=1,editTool='push-pull',editDrag=null;
let editUndoUI=[],editRedoUI=[];
const featurePrepared={flow:false,explode:false,massing:false};
const diagnostics={version:'1.0.0',errors:[],exports:[],routes:[],imports:[]};
window.addEventListener('error',e=>{if(e.message.includes('ResizeObserver loop'))return;diagnostics.errors.push(e.message);toast('页面发生错误：'+e.message)});
window.addEventListener('unhandledrejection',e=>{diagnostics.errors.push(String(e.reason));toast(String(e.reason?.message||e.reason))});
const escapeHtml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(msg){$('toast').textContent=msg;$('toast').classList.add('visible');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').classList.remove('visible'),5500);$('status').textContent=msg;}
function fromB64(s){return Uint8Array.from(atob(s),c=>c.charCodeAt(0));}
function toB64(a){let s='';for(let i=0;i<a.length;i+=32768)s+=String.fromCharCode(...a.subarray(i,i+32768));return btoa(s);}
function vec(p){return new THREE.Vector3(...p)}
function clearGroup(group){while(group.children.length){let o=group.children[0];group.remove(o);o.traverse(c=>{if(!c.userData.sharedGeometry)c.geometry?.dispose();if(c.material){for(const m of Array.isArray(c.material)?c.material:[c.material])if(!m.userData.shared)m.dispose();}});}}
function level(){return data.levels[Number($('floor').value)||0]}
function hasGroundedMassing(){return false;}
function floorIndex(z){let i=0;for(let j=0;j<data.levels.length;j++)if(data.levels[j].base<=z+.35)i=j;return i;}
function liftPoint(p,r){const levels=data.levels,index=levels.findIndex(l=>l.id===r.levelId),flat=r.points.every(q=>Math.abs(q[2]-r.points[0][2])<.08);return levelLift(p,levels.map(l=>l.base),index>=0?index:floorIndex(p[2]-.28),Number($('explode').value),flat);}
function boundsBox(includeSite=true){const b=data.buildingBounds,box=new THREE.Box3(vec(b[0]),vec(b[1]));if(mode==='massing'){if(includeSite)for(const mesh of modelMeshes)if(mesh.userData.role==='site')box.union(mesh.geometry.boundingBox);for(let stage=2;stage<=5;stage++)for(const part of massingSession?.getSelected(stage)?.parts||[])if(part.bounds)box.union(new THREE.Box3(vec(part.bounds[0]),vec(part.bounds[1])));}return box;}
function setBusy(value,label){busy=value;$('loading').hidden=!value;if(label)$('loading').textContent=label;}
async function task(fn){if(busy)return;setBusy(true,'正在生成，请稍候…');await new Promise(r=>setTimeout(r,35));try{await fn()}catch(e){diagnostics.errors.push(e.message);toast(e.message)}finally{setBusy(false);render();}}
function setCamera(view='iso',fit=true){cameraMode=view;const center=boundsBox().getCenter(new THREE.Vector3());center.z+=Number($('explode').value)*(data.levels.length-1)/2;controls.target.copy(center);camera.position.copy(center).add(view==='top'?new THREE.Vector3(0,-.01,200):new THREE.Vector3(-95,-115,86));camera.up.set(0,0,1);camera.lookAt(center);controls.update();if(fit)fitCamera();render();}
function fitCamera(aspectOverride,includeSite=true,extraBounds=null){const box=boundsBox(includeSite);if(extraBounds&&!extraBounds.isEmpty())box.union(extraBounds);if(mode==='flow'&&Number($('explode').value)===0&&Number($('cut').value)<Number($('cut').max))box.max.z=Math.min(box.max.z,Number($('cut').value));box.max.z+=Number($('explode').value)*(data.levels.length-1);const c=box.getCenter(new THREE.Vector3()),delta=c.clone().sub(controls.target);camera.position.add(delta);controls.target.copy(c);camera.lookAt(c);camera.updateMatrixWorld();let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;for(let x of [box.min.x,box.max.x])for(let y of [box.min.y,box.max.y])for(let z of [box.min.z,box.max.z]){let p=new THREE.Vector3(x,y,z).applyMatrix4(camera.matrixWorldInverse);minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y);}const a=aspectOverride||viewport.clientWidth/viewport.clientHeight,h=Math.max(maxY-minY,(maxX-minX)/a)*1.18;camera.top=h/2;camera.bottom=-h/2;camera.left=-h*a/2;camera.right=h*a/2;camera.zoom=1;camera.updateProjectionMatrix();thumbDirty=true;}
function resize(){const w=viewport.clientWidth,h=viewport.clientHeight;renderer.setSize(w,h,false);const span=camera.top-camera.bottom;camera.left=-span*w/h/2;camera.right=span*w/h/2;camera.updateProjectionMatrix();render();}
new ResizeObserver(resize).observe(viewport);controls.addEventListener('change',()=>{thumbDirty=true;render();});
function meshMaterial(role){return new THREE.MeshStandardMaterial({color:0xf0f0ea,roughness:.92,metalness:0,side:THREE.DoubleSide,clippingPlanes:[planeTop,planeBottom],transparent:role==='glass',opacity:role==='glass'?.2:1,depthWrite:role!=='glass'});}
function addMesh(geometry,info){geometry.computeVertexNormals();geometry.computeBoundingBox();const material=meshMaterial(info.role);const mesh=new THREE.Mesh(geometry,material);mesh.userData={...info};modelRoot.add(mesh);modelMeshes.push(mesh);const edges=new THREE.LineSegments(new THREE.EdgesGeometry(geometry,40),new THREE.LineBasicMaterial({color:0x596b60,transparent:true,opacity:.11,clippingPlanes:[planeTop,planeBottom]}));mesh.add(edges);mesh.userData.edges=edges;const a=geometry.index?geometry.toNonIndexed().getAttribute('position').array:geometry.getAttribute('position').array;navMeshes.push({positions:a,role:info.role});return mesh;}
async function loadData(payload,restore=true){
  if(!payload?.meshes?.length)throw Error('文件中没有可读取的模型网格。');
  stopEvolution();cancelEditDrag();editPartId=null;editUndoUI=[];editRedoUI=[];disposeLiveViews();clearGroup(modelRoot);clearGroup(routesRoot);clearGroup(massingRoot);modelMeshes=[];navMeshes=[];massingGroups=[];massingImages=[];massingSession=null;savedMassingChoices=null;candidateRounds={};shownCandidates=[];candidateIndex=null;explodeLevels=[];navCache.clear();routes=[];selected=null;flowAutoGenerateSuppressed=false;data=payload;geometryRevision++;publicationRevision=null;pendingPublication=null;
  for(const key of Object.keys(featurePrepared))featurePrepared[key]=false;
  for(const b of payload.meshes){const g=new THREE.BufferGeometry();const p=typeof b.positions==='string'?new Float32Array(fromB64(b.positions).buffer):new Float32Array(b.positions);g.setAttribute('position',new THREE.BufferAttribute(p,3));if(b.colors){const c=typeof b.colors==='string'?fromB64(b.colors):new Uint8Array(b.colors);g.setAttribute('color',new THREE.BufferAttribute(c,3,true));}addMesh(g,{levelIndex:b.levelIndex||0,role:b.role||'building',baseColor:b.color||'#dedfd6'});}
  if(!data.buildingBounds){const box=new THREE.Box3().setFromObject(modelRoot);data.buildingBounds=[box.min.toArray(),box.max.toArray()];}
  if(!data.levels?.length){const b=data.buildingBounds,z=b[0][2],height=b[1][2]-z,count=Math.max(1,Math.min(8,Math.round(height/4)));data.levels=Array.from({length:count},(_,i)=>({id:'F'+i,label:(i+1)+'层',base:z+i*height/count}));}
  if(!Array.isArray(data.massingSteps)||data.massingSteps.length!==6)data.massingSteps=defaultSteps();
  $('modelName').textContent=data.name||'导入模型';$('sourceNote').textContent=data.sourceStatus||'导入模型 · 楼层和演化草稿可调整';
  $('massingReference').hidden=!hasGroundedMassing();
  $('massingMethod').textContent=hasGroundedMassing()?'以当前模型已核实的几何证据逐格演化；第六格保留完整彩色源模型。':'前五格为通用形体表达草稿，需人工核对设计逻辑；第六格保留完整源模型。生成六步只补齐缺少步骤。';
  $('floor').innerHTML=data.levels.map((l,i)=>`<option value="${i}">${escapeHtml(l.label)} · ${l.base.toFixed(2)} m</option>`).join('');$('floor').value=String(Math.min(1,data.levels.length-1));
  $('levelValues').value=data.levels.map(l=>l.base).join(',');$('cut').max=Math.ceil(data.buildingBounds[1][2]+1);$('cut').value=$('cut').max;$('explode').value=0;
  if(restore){try{const s=JSON.parse(localStorage.getItem(storageKey()));if(s){routes=(s.routes||[]).map(r=>({...r,type:inferFlowType(r)}));flowPage=FLOW_PAGES[s.flowPage]?s.flowPage:'work';flowAutoGenerateSuppressed=s.flowAutoGenerateSuppressed===true;data.massingSteps=s.steps||data.massingSteps;savedMassingChoices=s.massingChoices||null;candidateRounds=s.candidateRounds||{};data.massingDiagram=s.massingDiagram||data.massingDiagram;data.massingViews=s.massingViews||data.massingViews;publicationRevision=s.publicationRevision||null;if(publicationRevision===pendingPublication?.revision)pendingPublication=null;}}catch{}}
  $('diagramTone').value=diagramSettings().tone;$('diagramAnnotations').checked=diagramSettings().annotations;$('massingVariants').hidden=hasGroundedMassing();
  $('stepSelect').innerHTML=data.massingSteps.map((l,i)=>`<option value="${i}">0${i+1} ${escapeHtml(l.title)}</option>`).join('');updateStepEditor();
  selected=routes[0]?.id||null;updateRouteList();applyStyle();setCamera('iso');updateScene();
  $('modelInfo').textContent=`${Math.round(navMeshes.reduce((s,m)=>s+m.positions.length/9,0)).toLocaleString()} 个三角面`;
  $('status').textContent='模型已载入。选择分析功能后再生成专用内容。';setBusy(false);diagnostics.imports.push({name:data.name,meshes:modelMeshes.length,triangles:navMeshes.reduce((s,m)=>s+m.positions.length/9,0)});if(mode==='massing'){buildMassing();await refreshGrid();}
}
function storageKey(){return 'massing-six-grid-v1:'+String(data?.sourceSha256||data?.name||'model');}
function persist(){if(!data)return;try{localStorage.setItem(storageKey(),JSON.stringify({routes,flowPage,flowAutoGenerateSuppressed,steps:data.massingSteps,massingDiagram:data.massingDiagram,massingViews:data.massingViews,publicationRevision,massingChoices:massingSession?.exportChoices()||savedMassingChoices,candidateRounds}));}catch{} }
function applyStyle(){for(const mesh of modelMeshes){const m=mesh.material,role=mesh.userData.role;m.vertexColors=style==='material'&&!!mesh.geometry.getAttribute('color');m.color.set(style==='zones'?colorPalette[mesh.userData.levelIndex%colorPalette.length]:style==='material'?mesh.userData.baseColor:'#f0f0ea');if(m.vertexColors)m.color.set('#ffffff');m.transparent=role==='glass'||$('ghost').checked;m.opacity=role==='glass'?.13:$('ghost').checked?.23:1;m.depthWrite=!m.transparent;m.needsUpdate=true;mesh.userData.edges.material.opacity=$('ghost').checked?.06:.11;}for(const [id,v] of [['whiteMode','white'],['materialMode','material'],['zoneMode','zones']])$(id).classList.toggle('active',v===style);$('viewSubtitle').textContent=(style==='white'?'白模':style==='zones'?'楼层色块':'基础材质')+' / '+(cameraMode==='top'?'俯视平面':'轴测视角');render();}
function updateScene(){if(!data)return;const cut=Number($('cut').value),explode=Number($('explode').value);planeTop.constant=cut>=Number($('cut').max)?10000:cut;planeBottom.constant=cameraMode==='top'?-level().base+.4:10000;
  $('cutValue').textContent=planeTop.constant===10000?'完整':cut.toFixed(1)+' m';$('explodeValue').textContent=explode.toFixed(1)+' m';
  for(const mesh of modelMeshes){const u=mesh.userData;mesh.visible=(u.role!=='site'||$('showSite').checked)&&(u.role!=='furniture'||$('showFurniture').checked);mesh.position.z=u.role==='site'?0:(u.explodeLevel??u.levelIndex)*explode;}
  rebuildRoutes();render();
}
function currentFlowTypes(){return FLOW_PAGES[flowPage].types;}
function pageRoutes(){return routes.filter(r=>r.levelId===level().id&&flowMatchesPage(r,flowPage));}
function updateFlowPresentation(){
  document.querySelectorAll('[data-flow-page]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.flowPage===flowPage)));
  $('flowIntro').textContent=FLOW_PAGES[flowPage].description;
  const current=pageRoutes(),types=currentFlowTypes();
  $('flowTypeSummary').innerHTML=types.map(type=>`<span class="flow-type-chip" style="--chip-color:${FLOW_TYPES[type].color}"><i></i>${FLOW_TYPES[type].title} ${current.filter(r=>inferFlowType(r)===type).length}</span>`).join('');
  $('autoRoutes').textContent=`生成本层${FLOW_PAGES[flowPage].title}流线`;
  $('clearRoutes').textContent=`清除本层本页流线（${current.length}）`;
  $('clearRoutes').disabled=current.length===0;
  $('clearAllRoutes').textContent=`清除所有楼层、所有类型的流线（${routes.length}）`;
  $('clearAllRoutes').disabled=routes.length===0;
  $('flowEmpty').textContent=current.length?'':flowPage==='vertical'?'本层暂无已核对的楼梯联系；可手动点选起终点。':'本页暂无流线；点击生成，或手动点选起终点。';
  const legendTypes=mode==='flow'?types:['public','work','meeting','vertical'];
  $('legend').innerHTML=legendTypes.map(type=>`<span><i style="background:${FLOW_TYPES[type].color}"></i>${FLOW_TYPES[type].title}</span>`).join('');
}
function setFlowPage(next){if(!FLOW_PAGES[next])return;flowPage=next;selected=pageRoutes()[0]?.id||null;updateRouteList();rebuildRoutes();}
function addRoute(points,name,color=null,meta={}){if(points.length<2)return;const type=meta.type||currentFlowTypes()[0],route={id:crypto.randomUUID(),name,color:color||FLOW_TYPES[type].color,width:.18,lineStyle:'solid',levelId:level().id,points,source:'手绘示意',...meta,type};routes.push(route);selected=route.id;updateRouteList();rebuildRoutes();persist();reportFeature('flow');return route;}
function updateRouteList(){const sel=$('routeList'),shown=$('flowAdvanced').open?routes:pageRoutes();$('routeListLabel').textContent=$('flowAdvanced').open?'所有楼层与类型的流线（高级编辑）':'本层本页流线';if(!shown.some(r=>r.id===selected))selected=shown[0]?.id||null;sel.innerHTML=shown.length?shown.map(r=>`<option value="${r.id}">${$('flowAdvanced').open?`[${FLOW_TYPES[inferFlowType(r)].title}] `:''}${escapeHtml(r.name)}</option>`).join(''):'<option value="">尚无流线</option>';sel.value=selected||'';const r=routes.find(r=>r.id===selected);$('routeEditor').hidden=!r;if(r){$('routeName').value=r.name;$('routeType').value=inferFlowType(r);$('routeColor').value=r.color;$('routeStyle').value=r.lineStyle;$('routeWidth').value=r.width;$('routePoints').value=r.points.map(p=>p.map(n=>Number(n.toFixed(3))).join(', ')).join('\n');}updateFlowPresentation();}
function currentRoute(){return routes.find(r=>r.id===selected)}
function routeRenderPoints(r){
  if(!r.gridCell&&!String(r.source).includes('网格'))return r.points;
  const l=data.levels.find(l=>l.id===r.levelId);if(!l)return r.points;
  const key=geometryRevision+':'+l.base;
  try{if(!navCache.has(key))navCache.set(key,buildGrid(navMeshes,data.buildingBounds,l.base));return simplifyGridRoute(navCache.get(key),r.points);}
  catch{return r.points;}
}
function buildArrowRoute(r){const group=new THREE.Group(),points=routeRenderPoints(r).map(p=>vec(liftPoint(p,r))),depth=!$('xrayRoutes').checked,material=new THREE.MeshBasicMaterial({color:r.color,depthTest:depth,depthWrite:depth});const curve=new THREE.CurvePath();for(let i=1;i<points.length;i++)if(points[i].distanceTo(points[i-1])>.001)curve.add(new THREE.LineCurve3(points[i-1],points[i]));const length=curve.getLength();if(!length)return group;const radius=Number(r.width)/2;
  if(r.lineStyle==='dashed'){const dash=Math.max(.45,r.width*4),gap=dash*.65;for(let s=0;s<length;s+=dash+gap){const a=curve.getPoint(s/length),b=curve.getPoint(Math.min(1,(s+dash)/length));segmentTube(group,a,b,radius,material);}}
  else{const tube=new THREE.Mesh(new THREE.TubeGeometry(curve,Math.max(8,Math.min(250,Math.ceil(length/.3))),radius,6,false),material);group.add(tube);}
  const count=Math.max(1,Math.floor(length/5)),arrows=[];for(let i=0;i<count;i++){const cone=new THREE.Mesh(new THREE.ConeGeometry(Math.max(.25,r.width*2.1),Math.max(.65,r.width*4.4),8),material);group.add(cone);arrows.push(cone);}
  group.userData={route:r,curve,length,arrows};placeArrowheads(group,0);group.traverse(o=>o.renderOrder=depth?3:90);return group;
}
function segmentTube(g,a,b,r,m){const delta=b.clone().sub(a),len=delta.length();if(len<.001)return;const o=new THREE.Mesh(new THREE.CylinderGeometry(r,r,len,6),m);o.position.copy(a).addScaledVector(delta,.5);o.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize());g.add(o);}
function placeArrowheads(group,t){const {curve,arrows}=group.userData;if(!curve)return;arrows.forEach((a,i)=>{const u=arrows.length===1?.92:((i+.85)/arrows.length+t)%1;const p=curve.getPoint(Math.max(.005,Math.min(.995,u))),d=curve.getTangent(Math.max(.005,Math.min(.995,u))).normalize();a.position.copy(p);a.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d);});}
function routeVisible(r){const cut=Number($('cut').value);return (mode!=='flow'||r.levelId===level().id&&flowMatchesPage(r,flowPage))&&(cameraMode!=='top'||r.levelId===level().id)&&Math.min(...r.points.map(p=>p[2]))<cut;}
function rebuildRoutes(){clearGroup(routesRoot);for(const r of routes){const o=buildArrowRoute(r);o.visible=routeVisible(r);routesRoot.add(o);}render();}
function renderLabels(){const box=viewport.getBoundingClientRect();$('labels').replaceChildren();if(!['flow','explode'].includes(mode)||evolving)return;for(const r of routes){if(!routeVisible(r))continue;const p=vec(liftPoint(r.points[r.points.length-1],r)).project(camera);if(Math.abs(p.x)>1||Math.abs(p.y)>1||Math.abs(p.z)>1)continue;const el=document.createElement('div');el.className='route-tag';el.textContent=r.name;el.style.borderColor=r.color;el.style.left=(p.x*.5+.5)*box.width+'px';el.style.top=(-p.y*.5+.5)*box.height+'px';$('labels').append(el);}}
function render(){if(!data)return;modelRoot.visible=mode==='flow'||mode==='explode'||evolving&&stepIndex===5;routesRoot.visible=mode==='flow'||mode==='explode';massingRoot.visible=mode==='massing'&&evolving&&stepIndex!==5;renderer.render(scene,camera);renderLabels();}
function getGrid(){const k=geometryRevision+':'+level().base;if(!navCache.has(k)){const grid=buildGrid(navMeshes,data.buildingBounds,level().base);if(!grid.count)throw Error('当前标高没有识别到可通行楼板，请调整楼层标高。');navCache.set(k,grid);}return navCache.get(k);}
async function autoRoutes(){if(!data.roomLabels&&flowPage!=='vertical'){startPicking('path');toast('导入模型没有可识别的房间名称，请在俯视图点选起终点，并在高级设置里指定类型。');return;}
  await task(async()=>{const l=level();let added=0,failed=0,targets=0;
    if(flowPage!=='vertical'){
      const doors=(data.doors||[]).filter(d=>d.level===l.id&&d.role.includes('交通核西墙'));
      const anchors=doors.map(d=>{const o=d.opening;return [o[0]-.6,(o[1]+o[3])/2,l.base];});
      if(!anchors.length)anchors.push([data.buildingBounds[0][0]+2,data.buildingBounds[0][1]+2,l.base]);
      const dests=(data.roomLabels[l.id]||[]).filter(r=>!/(电梯|楼梯|卫生间|止于|净高)/.test(r.text)&&currentFlowTypes().includes(inferFlowType({name:r.text})));
      targets=dests.length;const g=dests.length?getGrid():null;
      for(const d of dests){const type=inferFlowType({name:d.text});let best=null;for(const a of anchors){const result=findPath(g,a,d.world,2.3);if(result.ok&&(!best||result.length<best.length))best=result;}if(best&&best.length>1){const name=d.text.replace(/ · .*$/,'');if(routes.some(r=>r.levelId===l.id&&r.name===name))continue;addRoute(best.points,name,FLOW_TYPES[type].color,{type,source:'本层网格自动寻路 · 待人工复核',length:best.length,gridCell:g.cell,clearance:g.clearance});added++;diagnostics.routes.push({level:l.id,name,type,ok:true,length:best.length,cells:best.cells.length});}else failed++;}
    }else{
      const known=(data.knownRoutes||[]).filter(r=>r.mode==='stairs'&&r.levelId===l.id);targets=known.length;
      for(const r of known){if(routes.some(a=>a.referenceId===r.id))continue;addRoute(r.points.map(p=>[p[0],p[1],p[2]+.3]),r.id.includes('grand')?'大阶梯步行段':'二至三层楼梯',FLOW_TYPES.vertical.color,{type:'vertical',referenceId:r.id,source:'已有模型行走路径段 · 待人工复核'});added++;}
    }
    $('cut').value=Math.min(Number($('cut').max),l.base+1.8);updateScene();fitCamera();render();updateRouteList();
    toast(added?`本页新增 ${added} 条流线${failed?`；${failed} 个目的地未连通，未画穿墙路径`:''}。`:
      targets?'本页已有对应流线；可切换楼层或手动调整。':'本层没有可确定的本类目的地，可手动点选起终点。');});
}
function startPicking(which){mode==='massing'&&setMode('flow');drawMode=which;pickPoints=[];$('explode').value=0;setCamera('top');$('cut').value=Math.min(Number($('cut').max),level().base+1.8);updateScene();canvas.style.cursor='crosshair';toast(which==='path'?'依次点选起点、终点，自动计算可通行路径。':'连续点击添加路径点，完成后点“结束绘制”。');}
let down=null;canvas.addEventListener('pointerdown',e=>down=[e.clientX,e.clientY]);canvas.addEventListener('pointerup',e=>{if(!drawMode||!down||Math.hypot(e.clientX-down[0],e.clientY-down[1])>5)return;const rect=canvas.getBoundingClientRect(),mouse=new THREE.Vector2((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1),ray=new THREE.Raycaster();ray.setFromCamera(mouse,camera);const p=new THREE.Vector3();if(!ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0,0,1),-level().base-.28),p))return;pickPoints.push(p.toArray());if(drawMode==='path'&&pickPoints.length===2){try{const r=findPath(getGrid(),...pickPoints);if(!r.ok)throw Error(r.reason);addRoute(r.points,'自定义流线',null,{source:'点选起终点 · 网格寻路',length:r.length});toast(`已生成 ${r.length.toFixed(1)} m 流线。`)}catch(err){toast(err.message)}drawMode=null;pickPoints=[];canvas.style.cursor='';}else toast(`已放置 ${pickPoints.length} 个点${drawMode==='path'?'，继续选择终点':'，可继续添加或结束绘制'}。`);});
function defaultSteps(){return [{title:'单一基础体块',note:'以一个正方体或长方体确定建筑的总体范围。'},{title:'第一次操作',note:'在基础体块上完成一次清楚的体块变化。'},{title:'第二次操作',note:'在上一格基础上再完成一次明确的形体操作。'},{title:'第三次操作',note:'延续已选操作，再增加一处体块变化。'},{title:'第四次操作',note:'用一次新的形体操作完善主体轮廓。'},{title:'完整彩色模型',note:'展示导入的完整模型、材质与细节；作为演化结果的对照。'}];}
function generatedMassingNote(note){return /^将现有体块沿(东西|南北|竖向)分为两个，留下清晰可见的分块间隙。$|^从现有体块的[东南西北]{2}角切出一个明显的缺口，形成转折轮廓。$|^在现有体块.+补出一个附加角部，形成可辨认的外伸轮廓。$/.test(note||'');}
function syncSelectedMassingSteps(){
  if(!massingSession)return false;
  const defaults=defaultSteps(),generatedTitles=new Set(['分成两个体块','切掉一个角','补上一个角']);let changed=false;
  for(let stage=2;stage<=5;stage++){
    const candidate=massingSession.getSelected(stage);if(!candidate)continue;
    const i=stage-1,current=data.massingSteps[i]||defaults[i],title=candidate.operationLabel||candidate.operation?.label||candidate.title,note=candidate.operation?.summary||candidate.note;
    const titleWasGenerated=current.autoGenerated===true||current.autoGenerated!==false&&(current.title===defaults[i].title||generatedTitles.has(current.title));
    const noteWasGenerated=current.autoGenerated===true||current.autoGenerated!==false&&(current.note===defaults[i].note||generatedMassingNote(current.note));
    const next={...current,title:titleWasGenerated?title:current.title,note:noteWasGenerated?note:current.note,autoGenerated:titleWasGenerated&&noteWasGenerated};
    if(next.title!==current.title||next.note!==current.note||next.autoGenerated!==current.autoGenerated){data.massingSteps[i]=next;changed=true;}
  }
  if(changed){const currentValue=$('stepSelect').value;$('stepSelect').innerHTML=data.massingSteps.map((step,i)=>`<option value="${i}">0${i+1} ${escapeHtml(step.title)}</option>`).join('');$('stepSelect').value=currentValue;updateStepEditor();}
  return changed;
}
function massMaterial(color='#e4e8df',opacity=1){return new THREE.MeshStandardMaterial({color,roughness:1,side:THREE.DoubleSide,transparent:opacity<1,opacity});}
function boxMesh(lo,hi,color){const sz=vec(hi).sub(vec(lo)),o=new THREE.Mesh(new THREE.BoxGeometry(sz.x,sz.y,sz.z),massMaterial(color));o.position.copy(vec(lo).add(vec(hi)).multiplyScalar(.5));const edge=new THREE.LineSegments(new THREE.EdgesGeometry(o.geometry),new THREE.LineBasicMaterial({color:0x6c7b6e,transparent:true,opacity:.22}));o.add(edge);return o;}
function plateMesh(poly,z,depth,holes=true,color='#e4e8df'){const s=new THREE.Shape(poly.exterior.map(p=>new THREE.Vector2(...p)));if(holes)for(const h of poly.holes||[])s.holes.push(new THREE.Path(h.map(p=>new THREE.Vector2(...p))));const g=new THREE.ExtrudeGeometry(s,{depth,bevelEnabled:false,curveSegments:1});g.translate(0,0,z);const m=new THREE.Mesh(g,massMaterial(color));m.add(new THREE.LineSegments(new THREE.EdgesGeometry(g,30),new THREE.LineBasicMaterial({color:0x6c7b6e,transparent:true,opacity:.18})));return m;}
function makeMassingPart(part){
  if(part.kind==='mesh'){
    const source=modelMeshes[part.sourceId];if(!source)return null;
    const mesh=new THREE.Mesh(source.geometry,massMaterial('#e4e8df'));mesh.userData.sharedGeometry=true;return mesh;
  }
  const [lo,hi]=part.bounds||data.buildingBounds;
  if(part.kind==='wedge'){
    const axis=part.riseAxis,other=1-axis;
    const shape=new THREE.Shape([new THREE.Vector2(lo[axis],lo[2]),new THREE.Vector2(hi[axis],lo[2]),new THREE.Vector2(hi[axis],hi[2])]);
    const g=new THREE.ExtrudeGeometry(shape,{depth:hi[other]-lo[other],bevelEnabled:false});
    const pos=g.attributes.position;
    for(let i=0;i<pos.count;i++){const along=pos.getX(i),z=pos.getY(i),across=pos.getZ(i)+lo[other];pos.setXYZ(i,axis===0?along:across,axis===1?along:across,z);}
    g.computeVertexNormals();const mesh=new THREE.Mesh(g,massMaterial(part.color));
    mesh.add(new THREE.LineSegments(new THREE.EdgesGeometry(g,30),new THREE.LineBasicMaterial({color:0x6c7b6e,transparent:true,opacity:.18})));return mesh;
  }
  if(part.kind==='box')return boxMesh(lo,hi,part.color||'#e4e8df');
  if(part.kind==='plate'&&(part.poly||part.polygon))return plateMesh(part.poly||part.polygon,part.z??lo[2],part.depth??Math.max(.05,hi[2]-lo[2]),true,part.color||'#e4e8df');
  if(part.kind==='sphere'){const mesh=new THREE.Mesh(new THREE.SphereGeometry(1,28,20),massMaterial(part.color||'#e4e8df'));mesh.scale.copy(vec(hi).sub(vec(lo)).multiplyScalar(.5));mesh.position.copy(vec(hi).add(vec(lo)).multiplyScalar(.5));return mesh;}
  if(part.kind==='disc'||part.kind==='disk'){const size=vec(hi).sub(vec(lo)),mesh=new THREE.Mesh(new THREE.CylinderGeometry(Math.max(size.x,size.y)*.5,Math.max(size.x,size.y)*.5,Math.max(.2,size.z*.2),40),massMaterial(part.color||'#e4e8df'));mesh.rotation.x=Math.PI/2;mesh.position.copy(vec(hi).add(vec(lo)).multiplyScalar(.5));return mesh;}
  return null;
}
function diagramSettings(){return data.massingDiagram||{tone:'red',annotations:true};}
function story(stage){if(massingSession&&stage>=2&&stage<=5&&!massingSession.getSelected(stage))return {title:'待生成',english:'PENDING',reason:'前序改变后，请补齐或重新选择本阶段。'};const d=massingSession?.getDiagram(stage)||{},custom=data.massingSteps[stage-1]||{};return {...d,title:custom.autoGenerated===false?custom.title:d.title||custom.title,reason:custom.reason??d.reason??custom.note};}
function makeCandidateGroup(candidate,illustrate=false){
  const group=new THREE.Group(),diagram=illustrate?massingSession.getDiagram(candidate.stage):null,settings=diagramSettings();
  for(const part of candidate.parts||[]){const show=illustrate?{...part,color:settings.tone==='red'&&diagram?.highlightIds.includes(part.partId)?'#e9a398':'#f1f0eb'}:part;const mesh=makeMassingPart(show);if(mesh){mesh.name=part.partId||part.kind;mesh.userData.partId=part.partId;mesh.userData.partKind=part.kind;
    // A thin finish/platform can share a host surface; deterministic depth bias
    // avoids z-fighting without moving model dimensions. Roof caps are fixed in geometry.
    if(part.kind==='plate'){mesh.material.polygonOffset=true;mesh.material.polygonOffsetFactor=-1;mesh.material.polygonOffsetUnits=-1;}group.add(mesh);}}
  if(diagram&&settings.annotations){
    // Dashed boxes denote conceptual operation ranges, not measured removed volumes.
    for(const [lo,hi] of diagram.outlines){const size=vec(hi).sub(vec(lo)),box=new THREE.BoxGeometry(size.x,size.y,size.z),edge=new THREE.EdgesGeometry(box);box.dispose();const lines=new THREE.LineSegments(edge,new THREE.LineDashedMaterial({color:0xb87369,dashSize:.45,gapSize:.3,transparent:true,opacity:.65,depthTest:false}));lines.position.copy(vec(lo).add(vec(hi)).multiplyScalar(.5));lines.computeLineDistances();lines.renderOrder=6;group.add(lines);}
    for(const [a,b] of diagram.arrows){const start=vec(a),delta=vec(b).sub(start),length=delta.length();const arrow=new THREE.ArrowHelper(delta.normalize(),start,length,0xc63e30,.8,.38);arrow.traverse(o=>{if(o.material){o.material.depthTest=false;o.renderOrder=8;}});group.add(arrow);}
  }
  return group;
}
function rebuildSelectedMassing(){
  if(!massingSession)return;
  for(let stage=1;stage<=5;stage++){
    clearGroup(massingGroups[stage-1]);
    const candidate=massingSession.getSelected(stage);
    if(candidate){const group=makeCandidateGroup(candidate,true);while(group.children.length)massingGroups[stage-1].add(group.children[0]);}
  }
  thumbDirty=true;
}
function buildMassing(){
  clearGroup(massingRoot);massingGroups=[];
  const meshes=modelMeshes.map((mesh,id)=>({id,positions:mesh.geometry.getAttribute('position').array,bounds:[mesh.geometry.boundingBox.min.toArray(),mesh.geometry.boundingBox.max.toArray()],triangleCount:mesh.geometry.getAttribute('position').count/3,role:mesh.userData.role,levelIndex:mesh.userData.levelIndex,color:mesh.userData.baseColor}));
  massingSession=createMassingSession({meshes,buildingBounds:data.buildingBounds,levels:data.levels,plates:data.plates,cores:data.cores,columns:data.columns,stairs:data.stairs,bridges:data.bridges,sourceStatus:data.sourceStatus,sourceSha256:data.sourceSha256,name:data.name});
  let legacyReset=false;
  if(savedMassingChoices){try{const restored=massingSession.restoreChoices(savedMassingChoices);if(restored.migrationWarning)toast(restored.migrationWarning);}catch(error){diagnostics.errors.push('旧体块选择未恢复：'+error.message);savedMassingChoices=null;candidateRounds={};data.massingSteps=defaultSteps();$('stepSelect').innerHTML=data.massingSteps.map((step,i)=>`<option value="${i}">0${i+1} ${escapeHtml(step.title)}</option>`).join('');updateStepEditor();legacyReset=true;toast('旧版体块选稿与当前建筑几何不符，已重置选稿；模型和流线仍保留。');}}
  for(let i=0;i<6;i++){const group=new THREE.Group();group.visible=false;massingGroups.push(group);massingRoot.add(group);}
  rebuildSelectedMassing();const notesUpdated=syncSelectedMassingSteps();featurePrepared.massing=true;thumbDirty=true;if(legacyReset||notesUpdated)persist();
}
function prepareExplode(){
  explodeLevels=data.levels.map((l,index)=>({id:l.id,label:l.label,index,meshes:[]}));
  for(const mesh of modelMeshes){const index=Math.max(0,Math.min(explodeLevels.length-1,Number(mesh.userData.levelIndex)||0));mesh.userData.explodeLevel=index;explodeLevels[index].meshes.push(mesh);}
  featurePrepared.explode=true;
}
function cameraSnapshot(){return {position:camera.position.toArray(),target:controls.target.toArray(),up:camera.up.toArray(),left:camera.left,right:camera.right,top:camera.top,bottom:camera.bottom,zoom:camera.zoom};}
function restoreCamera(s){camera.position.fromArray(s.position);camera.up.fromArray(s.up);controls.target.fromArray(s.target);Object.assign(camera,{left:s.left,right:s.right,top:s.top,bottom:s.bottom,zoom:s.zoom});camera.updateProjectionMatrix();camera.lookAt(controls.target);controls.update();}
function snapshot(){return {mode,style,cut:$('cut').value,explode:$('explode').value,showSite:$('showSite').checked,showFurniture:$('showFurniture').checked,ghost:$('ghost').checked,camera:cameraSnapshot(),cameraMode};}
function restore(s){mode=s.mode;style=s.style;for(const k of ['cut','explode'])$(k).value=s[k];for(const k of ['showSite','showFurniture','ghost'])$(k).checked=s[k];cameraMode=s.cameraMode;restoreCamera(s.camera);applyStyle();updateScene();}
function rawImage(w=1600,h=1000,stage=null){
  const oldSize=renderer.getSize(new THREE.Vector2()),oldRatio=renderer.getPixelRatio(),left=camera.left,right=camera.right;
  const span=camera.top-camera.bottom,aspect=w/h;camera.left=-span*aspect/2;camera.right=span*aspect/2;camera.updateProjectionMatrix();renderer.setPixelRatio(1);renderer.setSize(w,h,false);
  const before=[modelRoot.visible,routesRoot.visible,massingRoot.visible];
  if(stage!==null){modelRoot.visible=stage===5;routesRoot.visible=false;massingRoot.visible=stage!==5;massingGroups.forEach((g,i)=>g.visible=i===stage);}
  const oldClear=renderer.getClearColor(new THREE.Color());if(stage!==null)renderer.setClearColor(0xffffff);
  renderer.render(scene,camera);renderer.setClearColor(oldClear);const out=document.createElement('canvas');out.width=w;out.height=h;out.getContext('2d').drawImage(canvas,0,0);
  [modelRoot.visible,routesRoot.visible,massingRoot.visible]=before;camera.left=left;camera.right=right;camera.updateProjectionMatrix();renderer.setPixelRatio(oldRatio);renderer.setSize(oldSize.x,oldSize.y,false);return out;
}
function analysisCanvas(w=2400,h=1600){const savedCamera=cameraSnapshot();fitCamera(w/(h-220));const out=document.createElement('canvas');out.width=w;out.height=h;const ctx=out.getContext('2d');ctx.fillStyle='#f8f8f4';ctx.fillRect(0,0,w,h);const areaH=h-220,image=rawImage(w,areaH);ctx.drawImage(image,0,110);ctx.fillStyle='#29392f';ctx.font='600 32px "PingFang SC",sans-serif';ctx.fillText(`${data.name} / ${mode==='explode'?'楼层展开':FLOW_PAGES[flowPage].title+'流线'}`,65,65);ctx.font='20px "PingFang SC",sans-serif';ctx.fillStyle='#7c877d';ctx.fillText(mode==='explode'?`层间距 ${Number($('explode').value).toFixed(1)} m · 白模空间关系示意`:`${level().label} · ${FLOW_PAGES[flowPage].types.map(t=>FLOW_TYPES[t].title).join(' / ')} · 自动流线为几何草稿`,65,h-49);
  const temp=camera.clone();const span=camera.top-camera.bottom;temp.left=-span*w/areaH/2;temp.right=span*w/areaH/2;temp.updateProjectionMatrix();temp.updateMatrixWorld();let labelIndex=0;for(const r of routes){if(!routeVisible(r))continue;const p=vec(liftPoint(r.points.at(-1),r)).project(temp);if(Math.abs(p.x)>.98||Math.abs(p.y)>.98)continue;const x=(p.x*.5+.5)*w+12,y=(-p.y*.5+.5)*areaH+110;ctx.font='22px "PingFang SC",sans-serif';const tw=ctx.measureText(r.name).width;const lx=Math.max(20,Math.min(w-tw-44,x)),ly=Math.max(145,Math.min(h-150,y));ctx.fillStyle='#ffffffee';ctx.fillRect(lx-8,ly-28,tw+24,40);ctx.fillStyle=r.color;ctx.fillRect(lx-12,ly-28,4,40);ctx.fillStyle='#34483b';ctx.fillText(r.name,lx,ly);labelIndex++;}
  restoreCamera(savedCamera);return out;
}
function wrapText(ctx,text,x,y,maxWidth,lineHeight,maxLines=3){let row='',lines=0;for(const ch of text){if(ctx.measureText(row+ch).width>maxWidth&&row){ctx.fillText(row,x,y+lines*lineHeight);row='';lines++;if(lines>=maxLines)return;}row+=ch;}if(row)ctx.fillText(row,x,y+lines*lineHeight);}
function sixCanvas(images,w=3360,h=2376){
  const out=document.createElement('canvas');out.width=w;out.height=h;const c=out.getContext('2d');c.fillStyle='#ffffff';c.fillRect(0,0,w,h);
  c.fillStyle='#202b28';c.font='600 46px "PingFang SC",sans-serif';c.fillText(`${data.name} / 体块推演`,90,96);c.font='23px sans-serif';c.fillStyle='#747d77';c.fillText('MASSING EVOLUTION     /     同一模型 · 六步空间逻辑',90,142);
  const gap=64,cw=(w-180-gap*2)/3,ch=(h-330-gap)/2;
  for(let i=0;i<6;i++){
    const x=90+i%3*(cw+gap),y=205+Math.floor(i/3)*(ch+gap),ih=ch-210,d=story(i+1),im=images[i];
    const scale=Math.min(cw/im.width,ih/im.height);c.drawImage(im,x+(cw-im.width*scale)/2,y+(ih-im.height*scale)/2,im.width*scale,im.height*scale);
    c.strokeStyle='#dce1dd';c.lineWidth=1;c.beginPath();c.moveTo(x,y+ih+12);c.lineTo(x+cw,y+ih+12);c.stroke();
    c.fillStyle='#c14536';c.font='600 42px sans-serif';c.fillText('0'+(i+1),x,y+ih+65);c.fillStyle='#25312a';c.font='600 32px "PingFang SC",sans-serif';c.fillText(d.title,x+75,y+ih+63);
    c.font='18px sans-serif';c.fillStyle='#7b817d';c.fillText(d.english||'FORM OPERATION',x+75,y+ih+96);c.font='25px "PingFang SC",sans-serif';wrapText(c,d.reason||'',x,y+ih+143,cw,36,2);
    if(i%3<2){const ax=x+cw+12,ay=y+ih*.5;c.strokeStyle='#c14536';c.lineWidth=4;c.beginPath();c.moveTo(ax,ay);c.lineTo(ax+38,ay);c.lineTo(ax+27,ay-9);c.moveTo(ax+38,ay);c.lineTo(ax+27,ay+9);c.stroke();}
  }
  c.fillStyle='#858a85';c.font='20px "PingFang SC",sans-serif';c.fillText('淡红：重点构件  /  红箭头：操作方向  /  虚线：前态轮廓或操作范围  ·  按编号阅读',90,h-67);
  c.fillText('模型空间解释稿；不代表真实设计历史。第六格为完整源模型对照。',90,h-33);return out;
}
function placeholderImage(w,h,stage){const out=document.createElement('canvas');out.width=w;out.height=h;const c=out.getContext('2d');c.fillStyle='#f4f6f1';c.fillRect(0,0,w,h);c.strokeStyle='#d9e0d8';c.lineWidth=2;c.strokeRect(15,15,w-30,h-30);c.fillStyle='#728477';c.textAlign='center';c.font=`${Math.max(18,Math.round(w/24))}px "PingFang SC",sans-serif`;c.fillText(`第 ${stage} 格 · 待选择`,w/2,h/2);return out;}
function allMassingSelected(){return !!massingSession&&!!massingSession.getSelected(1)&&[2,3,4,5].every(stage=>!!massingSession.getSelected(stage));}
function makeSixImages(w=1920,h=1080,{allowIncomplete=false}={}){
  if(!featurePrepared.massing)buildMassing();
  if(!allowIncomplete&&!allMassingSelected())throw Error('请按第二格到第五格的顺序，每格选定一次操作后再导出。');
  if(liveViews.length===6)return liveViews.map((v,i)=>v.root.children.length?renderLiveImage(v,w,h):placeholderImage(w,h,i+1));
  const s=snapshot();style='white';$('ghost').checked=false;$('cut').value=$('cut').max;$('explode').value=0;$('showSite').checked=false;$('showFurniture').checked=true;applyStyle();updateScene();fitCamera(w/h,false);
  const images=[];for(let i=0;i<5;i++)images.push(massingSession.getSelected(i+1)?rawImage(w,h,i):placeholderImage(w,h,i+1));
  style='material';$('showSite').checked=true;applyStyle();updateScene();images.push(rawImage(w,h,5));restore(s);return images;
}
async function refreshGrid(){
  if(mode!=='massing')return;
  rebuildLiveViews();massingImages=Array(6).fill(null);thumbDirty=false;render();
}
async function generateMassingDraft(){
  if(!featurePrepared.massing)buildMassing();const result=trackGeometryAction(()=>massingSession.completeDraft());savedMassingChoices=massingSession.exportChoices();syncSelectedMassingSteps();rebuildSelectedMassing();persist();await refreshGrid();updateCandidatePanel();reportFeature('massing');toast(result.added?`已补齐 ${result.added} 步，原有选稿保留。点击图格可修改空间理由。`:'六步已齐备，保留现有选稿与说明。');
}
function previewCandidate(candidate,target){
  const group=makeCandidateGroup(candidate),savedCamera=cameraSnapshot(),visibility=[modelRoot.visible,routesRoot.visible,massingRoot.visible],stageVisibility=massingGroups.map(g=>g.visible);
  massingRoot.add(group);massingGroups.forEach(g=>g.visible=false);modelRoot.visible=false;routesRoot.visible=false;massingRoot.visible=true;
  fitCamera(target.width/target.height,false,new THREE.Box3().setFromObject(group));const image=rawImage(target.width,target.height);target.getContext('2d').drawImage(image,0,0);
  massingRoot.remove(group);clearGroup(group);massingGroups.forEach((g,i)=>g.visible=stageVisibility[i]);[modelRoot.visible,routesRoot.visible,massingRoot.visible]=visibility;restoreCamera(savedCamera);render();
}
function blockCountLabel(candidate){
  if(hasGroundedMassing()){
    const operation=candidate?.operation?.type;
    const descriptions={};
    if(descriptions[operation])return descriptions[operation];
  }
  const count=Number(candidate?.blockCount);
  return Number.isInteger(count)&&count>0?`${count} 个体块`:'形体操作';
}
function updateCandidatePanel(){
  if(!massingSession)return;
  const stage=Number($('stepSelect').value)+1,selected=stage<=5?massingSession.getSelected(stage):null,available=stage>=2&&stage<=5&&!!massingSession.getSelected(stage-1),cards=$('candidateCards');
  $('stageStatus').textContent=stage===6?'第 6 格 · 完整彩色源模型':stage===1?'第 1 格 · 固定基础体块':`第 ${stage} 格 · ${selected?'已选用 '+selected.title:'待选用一次操作'}`;
  $('stageComplexity').textContent=stage===6?'真实模型':selected?blockCountLabel(selected):'待选操作';
  $('stageHint').textContent=stage===6?'完整模型的颜色和丰富细节在这里揭示；这一格不是“只做一次几何操作”的模拟结果。':stage===1?(hasGroundedMassing()?'第一格采用与真实建筑长向一致的单一长方体，作为后续推导的母体。':'第一格固定为一个正方体或长方体，作为后续操作的唯一母体。'):`在第 ${stage-1} 格基础上只增加一次${hasGroundedMassing()?'与源模型对应的建筑空间操作':'清楚的形体操作'}；${stage<5?`改选本格会清空第 ${stage+1}${stage+1<5?' 至第 5 格':' 格'}的选稿。`:'改选本格不会改变第 6 格的原始模型。'}`;
  const heading=document.querySelector('.candidate-heading');if(heading)heading.hidden=stage===1||stage===6||!available;
  cards.setAttribute('aria-label','当前阶段的可用操作候选');
  cards.hidden=!available;$('refreshCandidates').hidden=!available||hasGroundedMassing();$('useCandidate').hidden=!available;
  if(stage===1){shownCandidates=[];$('candidateNote').textContent=hasGroundedMassing()?'第一格已对应建筑主体。请根据最终模型提出第二格的操作。':'第一格已固定为一个基础体块。请进入第二格选择一次操作。';return;}
  if(stage===6){shownCandidates=[];$('candidateNote').textContent='第六格直接展示导入的完整彩色模型；可通过“原材质”查看颜色与细节。';return;}
  if(!available){shownCandidates=[];$('useCandidate').disabled=true;$('candidateNote').textContent=`请先选用第 ${stage-1} 格，再生成这一格。`;return;}
  if(hasGroundedMassing()){shownCandidates=[];cards.hidden=true;$('useCandidate').hidden=true;return;}
  const round=Number(candidateRounds[stage]||0);shownCandidates=massingSession.getCandidates(stage,round);candidateIndex=null;
  const allCards=[...cards.querySelectorAll('.candidate-card')];
  allCards.forEach((card,index)=>{
    const candidate=shownCandidates[index];card.hidden=!candidate;card.setAttribute('aria-pressed',String(!!candidate&&candidate.id===selected?.id));
    if(!candidate)return;
    card.querySelector('span').textContent=`${candidate.operationLabel||candidate.operation?.label||candidate.title}\n${candidate.operation?.presentation||blockCountLabel(candidate)}`;
    card.title=candidate.operation?.summary||candidate.title;
    previewCandidate(candidate,card.querySelector('canvas'));
  });
  $('useCandidate').disabled=true;
  $('candidateNote').textContent=selected?`当前已选「${selected.operationLabel||selected.title}」：${selected.operation?.summary||'已完成一次操作。'} ${stage<5?'可替换；后续选稿会重新生成。':'可替换；完整源模型保持不变。'}`:`从 ${shownCandidates.length} 种${hasGroundedMassing()?'表达中选一种（几何一致）':'操作中选一种'}，确定第 ${stage} 格。`;
}
function featureGenerated(feature){return feature==='flow'?routes.length>0:feature==='explode'?explodeLevels.length>0:allMassingSelected();}
function reportFeature(feature){if(window.parent!==window)window.parent.postMessage({type:'analysis-feature-ready',feature,generated:featureGenerated(feature)},location.origin);}
async function setMode(next,{autoGenerate=true}={}){
  if(!data||!['flow','explode','massing'].includes(next))return;
  if(next===mode&&featurePrepared[next]&&(next!=='massing'||massingImages.length===6)){reportFeature(next);return;}
  stopEvolution();const previous=mode;mode=next;$('generateMassing').hidden=next!=='massing';$('massingViewTools').hidden=next!=='massing';
  if(next!=='massing')setMassingEditing(false);
  if(previous==='explode'&&next!=='explode')$('explode').value=0;
  $('flowControls').hidden=next!=='flow';$('explodeControls').hidden=next!=='explode';$('massingControls').hidden=next!=='massing';$('explodeSliderControl').hidden=next!=='explode';
  $('sixGrid').hidden=next!=='massing';$('legend').hidden=next==='massing'||!routes.length;$('viewHint').hidden=next==='massing';
  $('viewTitle').textContent=next==='flow'?'空间与流线':next==='explode'?'楼层展开':'体块演化 · 六宫格';
  $('exportImage').textContent=next==='explode'?'导出当前楼层展开图':'导出当前分析图';
  document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===next));
  if(next==='flow'){
    const first=!featurePrepared.flow;featurePrepared.flow=true;
    if(shouldAutoGenerateFlow({firstEntry:first,requested:autoGenerate,cleared:flowAutoGenerateSuppressed,hasRoomLabels:!!data.roomLabels,routeCount:routes.length}))await autoRoutes();
    if(previous==='explode')setCamera('iso');
    updateRouteList();
  }
  if(next==='explode'){
    if(!featurePrepared.explode)prepareExplode();
    $('cut').value=$('cut').max;
    if(previous!=='explode'&&Number($('explode').value)===0)$('explode').value=String(Math.min(6,Number($('explode').max)));
    setCamera('iso');
    $('status').textContent=`已按 ${explodeLevels.length} 个楼层准备展开模型，可调至 16 米。`;
  }
  if(next==='massing'){
    setBusy(true,'正在生成六宫格体块分析…');
    try{if(!featurePrepared.massing)buildMassing();$('cut').value=$('cut').max;$('explode').value=0;setCamera('iso');const nextStage=[2,3,4,5].find(stage=>!massingSession.getSelected(stage))||5;$('stepSelect').value=String(nextStage-1);updateStepEditor();await refreshGrid();updateCandidatePanel();}
    finally{setBusy(false);}
  }
  applyStyle();updateScene();fitCamera();render();reportFeature(next);
}
async function selectFeature(feature,options){try{await setMode(feature,options);}catch(error){diagnostics.errors.push(error.message);toast(error.message);if(window.parent!==window)window.parent.postMessage({type:'analysis-feature-error',feature,message:error.message},location.origin);}}
function updateStepEditor(){const i=Number($('stepSelect').value)||0,s=data?.massingSteps?.[i];if(s){$('stepTitle').value=story(i+1).title||s.title;$('stepNote').value=s.note;$('stepReason').value=story(i+1).reason||'';}}
function showEvolutionStage(t){const total=6*Number($('duration').value);stepIndex=Math.min(5,Math.floor(t/Number($('duration').value)));massingGroups.forEach((g,i)=>g.visible=i===stepIndex);$('evolutionLabel').innerHTML=`${String(stepIndex+1).padStart(2,'0')} · ${escapeHtml(data.massingSteps[stepIndex].title)}<small>${escapeHtml(data.massingSteps[stepIndex].note)}</small>`;render();return t>=total;}
function stopEvolution(){if($('massingViewTools'))$('massingViewTools').hidden=mode!=='massing';evolving=false;cancelAnimationFrame(evolutionRaf);$('evolutionLabel').hidden=true;$('sixGrid').hidden=mode!=='massing';massingGroups.forEach(g=>g.visible=false);render();}
function playEvolution(){stopEvolution();mode='massing';evolving=true;$('massingViewTools').hidden=true;$('sixGrid').hidden=true;$('evolutionLabel').hidden=false;$('cut').value=$('cut').max;$('explode').value=0;$('showSite').checked=true;$('showFurniture').checked=true;style='material';applyStyle();updateScene();evolutionStart=performance.now();function tick(){if(!evolving)return;if(showEvolutionStage((performance.now()-evolutionStart)/1000)){stopEvolution();return;}evolutionRaf=requestAnimationFrame(tick);}tick();}
async function blobOf(c){return await new Promise(resolve=>c.toBlob(resolve,'image/png'));}
function safeExportName(name){
  const clean=String(name).replace(/[^\w\-\u4e00-\u9fff. ]/gu,'_').replace(/^[. ]+|[. ]+$/g,'');
  const extension=clean.match(/\.[A-Za-z0-9]{1,8}$/)?.[0]||'';
  const sourceStem=(extension?clean.slice(0,-extension.length):clean).replace(/[. ]+$/g,'')||'导出文件';
  const encoder=new TextEncoder();let stem='',bytes=encoder.encode(extension).length;
  for(const char of sourceStem){const width=encoder.encode(char).length;if(bytes+width>180||stem.length>=120)break;stem+=char;bytes+=width;}
  stem=stem.replace(/[. ]+$/g,'')||'导出文件';
  if(/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/i.test(stem))stem='导出_'+stem;
  return stem+extension;
}
async function emitFile(name,blob,notify=true){name=safeExportName(name);let record;try{const raw=new Uint8Array(await blob.arrayBuffer());const response=await fetch('/api/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,base64:toB64(raw)})});if(!response.ok)throw Error('save');record=await response.json();record.storage='workspace-exports';diagnostics.exports.push({name:record.name,bytes:blob.size,sha256:record.sha256,saved:true,storage:record.storage});if(notify){$('exportResult').hidden=false;$('exportLink').href=record.url;$('exportLink').textContent=record.name;}}catch{const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();record={name,url,saved:false,storage:'browser-download'};diagnostics.exports.push({name,bytes:blob.size,saved:false,storage:record.storage});if(notify){$('exportResult').hidden=false;$('exportLink').href=url;$('exportLink').textContent=name+'（浏览器下载）';}}return record;}
async function exportSix(includeZip=false){
  const images=makeSixImages(),sheet=sixCanvas(images);
  // One archive keeps the six stages, board and editable project together.
  const files={};
  for(let i=0;i<6;i++){
    const blob=await blobOf(images[i]);
    const name=`体块演化_${String(i+1).padStart(2,'0')}.png`;
    files[name]=new Uint8Array(await blob.arrayBuffer());
    // Stage images are included in the single ZIP download.
  }
  files['体块演化_六宫格.png']=new Uint8Array(await (await blobOf(sheet)).arrayBuffer());
  const packet=makeJimengPacket();
  files['即梦_演化分镜.json']=strToU8(JSON.stringify(packet,null,2));
  files['即梦_提示词.md']=strToU8(packet.transitions.map((t,i)=>
    `## ${i+1}. ${t.title}\n\n${t.prompt}\n\n首帧：${t.firstFrame}；尾帧：${t.lastFrame}；时长：${t.duration} 秒\n`).join('\n'));
  const interpretation=hasGroundedMassing()
    ?'第 1 格采用真实建筑包络；第 2 至第 5 格按本项目核实后的几何证据依次解释。每格是一次设计概念操作，候选仅调整强调颜色，不改变原建筑几何。第 6 格为完整彩色源模型。前五格不是实际设计历史，也不是施工模型；尚未向即梦提交。'
    :'第 1 格为单一正/长方体；第 2 至第 5 格各从前一格选择一次分块、切角或补角操作；第 6 格为完整彩色源模型对照。此图是解释草稿，不代表实际设计历史或工程模型；尚未向即梦提交。';
  files['分析方案.json']=strToU8(JSON.stringify(projectData()));
  files['六步空间逻辑.json']=strToU8(JSON.stringify({model:data.name,sourceSha256:data.sourceSha256,stages:Array.from({length:6},(_,i)=>({...story(i+1),detail:data.massingSteps[i].note})),diagram:diagramSettings()},null,2));
  files['模型来源与边界.json']=strToU8(JSON.stringify({
    source:data.name,revision:data.revision,sourceSha256:data.sourceSha256,
    massingChoices:massingSession.exportChoices(),interpretation
  },null,2));
  await emitFile(includeZip?'分析图模式_即梦演化素材.zip':'体块推演_六步图与逻辑.zip',
    new Blob([zipSync(files,{level:5})],{type:'application/zip'}));
  toast(includeZip?'六张图、六宫格与即梦分镜提示词已打包。':'六宫格、六张阶段图、空间逻辑及可恢复方案已打包。');
}
function makeJimengPacket(){
  const requested=Number($('duration').value),seconds=requested;
  return {platformNote:'实际生成前按所用平台当时支持的时长和模型核对；本包只生成提示词，不提交任务。',requestedEditDuration:requested,platformMinimumDuration:null,schema:'analysis-jimeng-2',model:data.name,sourceSha256:data.sourceSha256,massingChoices:massingSession?.exportChoices()||null,submitted:false,mode:'frames2video',transitions:Array.from({length:5},(_,i)=>{
    const operation=i<4?massingSession?.getSelected(i+2)?.operation:null;
    const instruction=operation?`只执行一次几何操作：${operation.summary||operation.label}。这一段保持白模。`:'第六格是完整彩色源模型的最终揭示，逐步显现已有细节与真实基础颜色；不把这些细节表述为一次几何操作。';
    return {title:data.massingSteps[i].title+' → '+data.massingSteps[i+1].title,operation:operation||null,firstFrame:`体块演化_${String(i+1).padStart(2,'0')}.png`,lastFrame:`体块演化_${String(i+2).padStart(2,'0')}.png`,duration:seconds,editDuration:requested,prompt:`建筑体块分析动画，固定正交轴测相机、构图、尺度、背景和光照。从首帧“${data.massingSteps[i].title}”平稳演化至尾帧“${data.massingSteps[i+1].title}”。${instruction}严格以提供的两张图为几何依据，不增添额外建筑，不旋转镜头，不漂移、不闪烁，不出现文字、标志或人物。时长 ${seconds} 秒。`};
  })};
}
async function exportSvg(){const savedCamera=cameraSnapshot();fitCamera(2400/1380);const w=2400,h=1600,areaH=h-220,temp=camera.clone(),span=camera.top-camera.bottom;temp.left=-span*w/areaH/2;temp.right=span*w/areaH/2;temp.updateProjectionMatrix();temp.updateMatrixWorld();const project=(p,r)=>{const q=vec(liftPoint(p,r)).project(temp);return [(q.x*.5+.5)*w,(-q.y*.5+.5)*areaH+110];};let body='';routes.filter(routeVisible).forEach((r,i)=>{const pts=routeRenderPoints(r).map(p=>project(p,r));body+=`<defs><marker id="a${i}" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L9,4.5 L0,9 Z" fill="${r.color}"/></marker></defs><polyline points="${pts.map(p=>p.map(n=>n.toFixed(2)).join(',')).join(' ')}" fill="none" stroke="${r.color}" stroke-width="${r.width/span*h}" stroke-linejoin="round" ${r.lineStyle==='dashed'?'stroke-dasharray="18 12"':''} marker-end="url(#a${i})"/><text x="${pts.at(-1)[0]+16}" y="${pts.at(-1)[1]}" font-size="24" fill="${r.color}" font-family="sans-serif">${escapeHtml(r.name)}</text>`;});await emitFile(`流线箭头_${FLOW_PAGES[flowPage].title}_${level().label}_可编辑.svg`,new Blob([`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><title>流线箭头叠加层（同机位，透视显示）</title>${body}</svg>`],{type:'image/svg+xml'}));restoreCamera(savedCamera);toast('已导出独立 SVG 箭头层，可在矢量软件中继续修改。');}
async function exportViews(){const s=snapshot(),files={};style='white';$('cut').value=$('cut').max;$('explode').value=0;$('ghost').checked=false;applyStyle();updateScene();routesRoot.visible=false;const center=boundsBox().getCenter(new THREE.Vector3()),dirs=[[-95,-115,86],[95,-115,86],[95,115,86],[-95,115,86],[0,-200,.1],[0,-.01,220]],names=['西南轴测','东南轴测','东北轴测','西北轴测','正面','俯视'];for(let i=0;i<6;i++){camera.position.copy(center).add(vec(dirs[i]));controls.target.copy(center);camera.lookAt(center);fitCamera();const c=rawImage(1920,1280,5),blob=await blobOf(c),name=`白模视角_${i+1}_${names[i]}.png`;files[name]=new Uint8Array(await blob.arrayBuffer());await emitFile(name,blob,false);}restore(s);await emitFile('白模_六个视角.zip',new Blob([zipSync(files,{level:5})],{type:'application/zip'}));toast('六个白模观察视角已导出；与六个演化阶段分别保存。');}
async function exportVideo(){if(!window.MediaRecorder)throw Error('此浏览器不支持视频录制，可先导出六张图。');const mime=['video/webm;codecs=vp9','video/webm;codecs=vp8','video/mp4'].find(t=>MediaRecorder.isTypeSupported(t));if(!mime)throw Error('浏览器没有可用的视频编码器。');const frames=makeSixImages(1280,820),out=document.createElement('canvas');out.width=1280;out.height=960;const ctx=out.getContext('2d'),stream=out.captureStream(30),chunks=[],recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:6000000}),sec=Number($('duration').value),total=sec*5+1;recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};const done=new Promise(resolve=>recorder.onstop=resolve);recorder.start();const start=performance.now();await new Promise(resolve=>{function tick(){const t=(performance.now()-start)/1000,idx=Math.min(4,Math.floor(t/sec)),u=Math.min(1,(t-idx*sec)/sec),alpha=THREE.MathUtils.smoothstep(u,.15,.85);ctx.fillStyle='#f8f8f4';ctx.fillRect(0,0,1280,960);ctx.globalAlpha=1;ctx.drawImage(frames[idx],0,0);ctx.globalAlpha=alpha;ctx.drawImage(frames[idx+1],0,0);ctx.globalAlpha=1;ctx.fillStyle='#344638';ctx.font='600 26px "PingFang SC",sans-serif';ctx.fillText(data.massingSteps[u<.5?idx:idx+1].title,50,862);ctx.fillStyle='#7b857d';ctx.font='18px "PingFang SC",sans-serif';ctx.fillText('体块演化预览 · 固定机位 / 本地溶解过渡',50,906);$('loading').textContent=`正在输出预览视频 ${Math.min(100,Math.round(t/total*100))}%`;if(t>=total){resolve();return;}requestAnimationFrame(tick);}tick();});recorder.stop();await done;stream.getTracks().forEach(t=>t.stop());await emitFile('体块演化_本地预览.'+(mime.includes('mp4')?'mp4':'webm'),new Blob(chunks,{type:mime}));toast('本地演化预览已导出。它是逐步溶解预览，尚未经过即梦生成。');}
async function importFiles(files){const list=[...files],primary=list.find(f=>/\.(glb|gltf|obj|stl|json|gz|html)$/i.test(f.name));if(!primary)throw Error('请选择 GLB、glTF、OBJ、STL、网格 JSON 或兼容模型网页。');const ext=primary.name.split('.').at(-1).toLowerCase();
  if(ext==='html'){const html=await primary.text(),doc=new DOMParser().parseFromString(html,'text/html'),el=doc.getElementById('model-data');if(!el)throw Error('此网页没有可读取的模型数据，请从原工具导出 GLB。');const raw=JSON.parse(el.textContent),bytes=await new Response(new Blob([fromB64(raw.geometry)]).stream().pipeThrough(new DecompressionStream('deflate'))).arrayBuffer(),dv=new DataView(bytes),groups=new Map();for(let i=0;i<bytes.byteLength;i+=20){const group=dv.getUint8(i+18),key=group;if(!groups.has(key))groups.set(key,{positions:[],colors:[],role:group===2?'site':'building',levelIndex:0});const g=groups.get(key);g.positions.push(dv.getFloat32(i,true),dv.getFloat32(i+4,true),dv.getFloat32(i+8,true));g.colors.push(dv.getUint8(i+15),dv.getUint8(i+16),dv.getUint8(i+17));}await loadData({schema:'analysis-model-1',name:primary.name.replace('.html',''),meshes:[...groups.values()],levels:raw.levels.map(l=>({id:l.id,label:l.label,base:l.base}))},false);return;}
  if(ext==='json'||ext==='gz'){const text=ext==='gz'?await new Response(primary.stream().pipeThrough(new DecompressionStream('gzip'))).text():await primary.text(),raw=JSON.parse(text);if(raw.schema==='analysis-project-1'){await restoreProject(raw);return;}if(raw.schema==='analysis-model-1'){await loadData(raw,false);return;}const meshes=Array.isArray(raw)?raw:raw.meshes;if(!Array.isArray(meshes)||!meshes[0]?.vertices)throw Error('JSON 需包含 vertices、faces 网格，或分析图模式保存的模型数据。');const group=new THREE.Group();for(const m of meshes){if(m.visible===false)continue;let p=[];for(const face of m.faces||[])for(let j=1;j<face.length-1;j++)for(const k of [face[0],face[j],face[j+1]])p.push(...m.vertices[k]);const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));const c=m.color||[220,220,220];group.add(new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:new THREE.Color(...c.map(v=>v/255))})));}await loadObject(group,primary.name,false);return;}
  let object;
  if(ext==='glb'||ext==='gltf'){const manager=new THREE.LoadingManager(),urls=new Map(list.map(f=>[f.name,URL.createObjectURL(f)]));manager.setURLModifier(url=>{if(url.startsWith('data:')||url.startsWith('blob:'))return url;const base=decodeURIComponent(url.split('/').at(-1));if(urls.has(base))return urls.get(base);throw Error('缺少 glTF 关联文件：'+base+'。请一并选择，或改用单文件 GLB。');});try{object=(await new GLTFLoader(manager).parseAsync(ext==='gltf'?await primary.text():await primary.arrayBuffer(),'')).scene;}catch(e){throw Error('模型读取失败：'+e.message+'。压缩 GLB 请先导出为未压缩 GLB。');}finally{for(const u of urls.values())URL.revokeObjectURL(u);}}
  if(ext==='obj')object=new OBJLoader().parse(await primary.text());if(ext==='stl')object=new THREE.Mesh(new STLLoader().parse(await primary.arrayBuffer()),new THREE.MeshStandardMaterial({color:0xdedfd6}));await loadObject(object,primary.name,ext==='glb'||ext==='gltf');
}
async function loadObject(object,name,isGltf){const scale=Number($('units').value),up=$('upAxis').value;object.scale.multiplyScalar(scale);if(up==='y'||up==='auto'&&isGltf)object.rotation.x+=Math.PI/2;object.updateMatrixWorld(true);const batch=[],box=new THREE.Box3().setFromObject(object),b=[box.min.toArray(),box.max.toArray()];if(!Number.isFinite(box.min.x)||box.isEmpty())throw Error('模型没有有效几何。');object.traverse(o=>{if(!o.isMesh)return;const g=o.geometry.clone().applyMatrix4(o.matrixWorld),non=g.index?g.toNonIndexed():g,p=non.getAttribute('position').array,col=non.getAttribute('color')?.array,mat=Array.isArray(o.material)?o.material[0]:o.material,c=mat?.color||new THREE.Color('#dedfd6');batch.push({positions:toB64(new Uint8Array(p.buffer,p.byteOffset,p.byteLength)),colors:col?toB64(Uint8Array.from(col,v=>Math.max(0,Math.min(255,Math.round(v*255))))):undefined,color:'#'+c.getHexString(),role:mat?.opacity<.8?'glass':'building',levelIndex:0});});await loadData({schema:'analysis-model-1',name:name.replace(/\.[^.]+$/,''),meshes:batch,buildingBounds:b,sourceStatus:'导入模型 · 基础色保留，楼层与演化步骤需核对',sourceSha256:await sha256(JSON.stringify(batch))},false);$('status').textContent='模型已导入。请核对楼层标高，再点选路径或查看体块演化。';}
async function sha256(s){const bytes=new TextEncoder().encode(s),hash=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(hash)].map(b=>b.toString(16).padStart(2,'0')).join('');}
function projectData(){return {schema:'analysis-project-1',version:'1.2.0',publicationRevision,savedAt:new Date().toISOString(),model:data,routes,massingChoices:massingSession?.exportChoices()||savedMassingChoices,candidateRounds,settings:{style,camera:cameraSnapshot(),floor:Number($('floor').value),flowPage,flowAutoGenerateSuppressed,cut:$('cut').value,explode:$('explode').value}};}
async function restoreProject(p){if(p.schema!=='analysis-project-1')throw Error('这不是分析图模式的方案文件。');await loadData(p.model,false);routes=(p.routes||[]).map(r=>({...r,type:inferFlowType(r)}));selected=routes[0]?.id||null;savedMassingChoices=p.massingChoices||null;candidateRounds=p.candidateRounds||{};publicationRevision=p.publicationRevision||null;const s=p.settings||{};style=s.style||'white';flowPage=FLOW_PAGES[s.flowPage]?s.flowPage:'work';flowAutoGenerateSuppressed=s.flowAutoGenerateSuppressed===true;$('floor').value=String(s.floor||0);$('cut').value=s.cut||$('cut').max;$('explode').value=s.explode||0;if(s.camera)restoreCamera(s.camera);if(mode==='massing')buildMassing();updateRouteList();applyStyle();updateScene();persist();if(mode==='massing'){await refreshGrid();updateCandidatePanel();}reportFeature(mode);toast(savedMassingChoices?'模型、流线、体块选稿和机位已恢复。':'模型、流线和机位已恢复；体块选稿请按新规则重新选择。');}
async function loadSample(){const r=await fetch('./data/demo-building.analysis.json');if(!r.ok)throw Error('示例模型读取失败，请通过本地启动器打开。');await loadData(await r.json());}
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>selectFeature(b.dataset.mode));
for(const [id,value] of [['whiteMode','white'],['materialMode','material'],['zoneMode','zones']])$(id).onclick=()=>{style=value;applyStyle()};
for(const id of ['showSite','showFurniture'])$(id).onchange=()=>updateScene();$('ghost').onchange=applyStyle;$('xrayRoutes').onchange=rebuildRoutes;
$('cut').oninput=updateScene;$('explode').oninput=()=>{if(Number($('explode').value)>0){$('cut').value=$('cut').max;if(cameraMode==='top')setCamera('iso');}updateScene();fitCamera();render()};$('floor').onchange=()=>{$('cut').value=Math.min(Number($('cut').max),level().base+1.8);navCache.clear();updateRouteList();updateScene();toast('已切换至'+level().label+'。')};
$('resetExplode').onclick=()=>{$('explode').value=0;updateScene();fitCamera();render();toast('楼层已恢复到未展开状态。');};
$('isoView').onclick=()=>{setCamera('iso');updateScene();if(mode==='massing')resetLiveDirection('iso')};$('topView').onclick=()=>{if(mode==='massing'){resetLiveDirection('top');return;}setCamera('top');$('cut').value=Math.min(Number($('cut').max),level().base+1.8);updateScene()};$('fitView').onclick=()=>{if(mode==='massing'&&liveViews.length){liveViews.forEach(fitLiveView);requestLiveRender();saveLiveViews();}else{fitCamera();render();}};
$('autoRoutes').onclick=autoRoutes;document.querySelectorAll('[data-flow-page]').forEach(b=>b.onclick=()=>{setFlowPage(b.dataset.flowPage);persist()});$('flowAdvanced').ontoggle=updateRouteList;$('pickRoute').onclick=()=>startPicking('path');$('drawRoute').onclick=()=>startPicking('draw');$('finishDraw').onclick=()=>{if(drawMode==='draw'&&pickPoints.length>1)addRoute(pickPoints,'手绘流线');drawMode=null;pickPoints=[];canvas.style.cursor='';toast('绘制已结束。')};$('undoPoint').onclick=()=>{pickPoints.pop();toast('已撤销最后一个点。')};
$('routeList').onchange=()=>{selected=$('routeList').value;updateRouteList()};for(const [id,key] of [['routeName','name'],['routeColor','color'],['routeStyle','lineStyle'],['routeWidth','width']])$(id).oninput=()=>{const r=currentRoute();if(!r)return;r[key]=key==='width'?Number($(id).value):$(id).value;rebuildRoutes();persist();if(key==='name')$('routeList').selectedOptions[0].textContent=r.name;};
$('routeType').onchange=()=>{const r=currentRoute();if(!r)return;r.type=$('routeType').value;r.color=FLOW_TYPES[r.type].color;updateRouteList();rebuildRoutes();persist();};
$('applyPoints').onclick=()=>{try{const p=$('routePoints').value.trim().split('\n').map(l=>l.trim().split(/[,，\s]+/).map(Number));if(p.length<2||p.some(x=>x.length!==3||x.some(n=>!Number.isFinite(n))))throw Error('至少两行，每行三个有效数字 X, Y, Z。');currentRoute().points=p;currentRoute().source='手动编辑路径';rebuildRoutes();persist();toast('路径坐标已更新。')}catch(e){toast(e.message)}};
$('reverseRoute').onclick=()=>{currentRoute()?.points.reverse();updateRouteList();rebuildRoutes();persist()};
function finishRouteClear(message){drawMode=null;pickPoints=[];canvas.style.cursor='';flowAutoGenerateSuppressed=true;selected=pageRoutes()[0]?.id||null;updateRouteList();rebuildRoutes();persist();reportFeature('flow');toast(message);}
$('deleteRoute').onclick=()=>{if(!selected)return;routes=routes.filter(r=>r.id!==selected);finishRouteClear('已删除所选流线。')};
$('clearRoutes').onclick=()=>{const count=pageRoutes().length;if(!count)return;routes=routesAfterPageClear(routes,level().id,flowPage);finishRouteClear(`已清除${level().label}「${FLOW_PAGES[flowPage].title}」的 ${count} 条流线，其他页面和楼层保留。`)};
$('clearAllRoutes').onclick=()=>{const count=routes.length;if(!count)return;if(!window.confirm(`将清除当前模型所有楼层、所有类型的 ${count} 条流线。确定继续？`))return;routes=[];finishRouteClear(`已清除当前模型的全部 ${count} 条流线。`)};
$('generateMassing').onclick=()=>task(generateMassingDraft);
for(const id of ['diagramTone','diagramAnnotations'])$(id).onchange=()=>{data.massingDiagram={tone:$('diagramTone').value,annotations:$('diagramAnnotations').checked};rebuildSelectedMassing();persist();refreshGrid();};
$('stepSelect').onchange=()=>{selectLiveView(Number($('stepSelect').value));updateStepEditor();updateCandidatePanel();};
document.querySelectorAll('.candidate-card').forEach(card=>card.onclick=()=>{const index=Number(card.dataset.candidateIndex);if(!shownCandidates[index])return;candidateIndex=index;document.querySelectorAll('.candidate-card').forEach(el=>el.setAttribute('aria-pressed',String(el===card)));$('useCandidate').disabled=false;const c=shownCandidates[index];$('candidateNote').textContent=`预览「${c.operationLabel||c.title}」：${c.operation?.summary||'本格完成一次操作。'} 操作后为${blockCountLabel(c)}；点击“选用并替换本格”确认。`;});
$('refreshCandidates').onclick=()=>{const stage=Number($('stepSelect').value)+1;if(stage<2||stage>5){toast('第 1 格固定为一个基础体块；第 6 格为完整模型。');return;}candidateRounds[stage]=Number(candidateRounds[stage]||0)+1;updateCandidatePanel();persist();};
$('useCandidate').onclick=()=>task(async()=>{const stage=Number($('stepSelect').value)+1;if(stage<2||stage>5||candidateIndex===null||!shownCandidates[candidateIndex])throw Error('请先选择一个操作候选。');const candidate=trackGeometryAction(()=>massingSession.select(stage,candidateIndex,Number(candidateRounds[stage]||0)));const label=candidate.operationLabel||candidate.operation?.label||candidate.title;data.massingSteps[stage-1]={title:label,note:candidate.operation?.summary||`${label}，形成 ${blockCountLabel(candidate)}。`,autoGenerated:true};for(let later=stage+1;later<=5;later++){delete candidateRounds[later];data.massingSteps[later-1]=defaultSteps()[later-1];}savedMassingChoices=massingSession.exportChoices();rebuildSelectedMassing();persist();if(stage<5){$('stepSelect').value=String(stage);updateStepEditor();}await refreshGrid();updateCandidatePanel();reportFeature('massing');toast(`第 ${stage} 格已选用「${label}」${stage<5?`，现在选择第 ${stage+1} 格的一次操作。`:'，六格体块已齐备。'}`);});
$('applyStep').onclick=()=>{const i=Number($('stepSelect').value);data.massingSteps[i]={title:$('stepTitle').value.trim()||'演化步骤',note:$('stepNote').value.trim(),reason:$('stepReason').value.trim(),autoGenerated:false};persist();refreshGrid();toast('已更新步骤说明。')};$('playEvolution').onclick=()=>{try{if(!allMassingSelected())throw Error('请先完成第 2 至第 5 格的一次操作选稿。');playEvolution();}catch(e){toast(e.message)}};$('stopEvolution').onclick=stopEvolution;
$('exportSix').onclick=()=>task(()=>exportSix());$('exportJimeng').onclick=()=>task(()=>exportSix(true));$('exportVideo').onclick=()=>task(exportVideo);$('exportViews').onclick=()=>task(exportViews);$('exportSvg').onclick=()=>task(exportSvg);$('exportImage').onclick=()=>task(async()=>{if(mode==='massing'){await emitFile('体块演化_六宫格.png',await blobOf(sixCanvas(makeSixImages())));}else await emitFile(mode==='explode'?`楼层展开_${Number($('explode').value).toFixed(1)}m.png`:`空间流线_${FLOW_PAGES[flowPage].title}_${level().label}.png`,await blobOf(analysisCanvas()));toast('分析图已导出，不包含操作界面。')});
$('saveProject').onclick=()=>task(async()=>{await emitFile('分析图方案_'+data.name+'.json',new Blob([JSON.stringify(projectData())],{type:'application/json'}));toast('方案已保存，含模型、流线、体块选稿和机位。')});$('openProject').onchange=e=>task(async()=>{await restoreProject(JSON.parse(await e.target.files[0].text()));e.target.value='';});$('importFile').onchange=e=>{const f=e.target.files;task(async()=>{await importFiles(f);e.target.value='';})};$('loadSample').onclick=()=>task(loadSample);
$('applyLevels').onclick=()=>{try{const a=$('levelValues').value.split(/[,，]/).map(Number);if(!a.length||a.some(n=>!Number.isFinite(n))||a.some((n,i)=>i&&n<=a[i-1]))throw Error('标高应为从低到高、互不重复的数字。');data.levels=a.map((z,i)=>({id:'custom-'+i,label:(i+1)+'层',base:z}));delete data.roomLabels;delete data.doors;delete data.knownRoutes;delete data.plates;routes=[];for(const m of modelMeshes){m.geometry.computeBoundingBox();m.userData.levelIndex=floorIndex(m.geometry.boundingBox.min.z);delete m.userData.explodeLevel;}data.meshes.forEach((m,i)=>m.levelIndex=modelMeshes[i].userData.levelIndex);$('floor').innerHTML=data.levels.map((l,i)=>`<option value="${i}">${l.label} · ${l.base} m</option>`).join('');navCache.clear();explodeLevels=[];featurePrepared.explode=false;featurePrepared.flow=false;savedMassingChoices=null;candidateRounds={};massingSession=null;featurePrepared.massing=false;if(mode==='massing'){buildMassing();refreshGrid().then(updateCandidatePanel);}updateScene();updateRouteList();persist();toast('楼层已更新。请重新选择体块候选并点选流线；旧楼层选择已清空。')}catch(e){toast(e.message)}};
$('closeResult').onclick=()=>$('exportResult').hidden=true;
$('animateRoutes').onchange=()=>{if(!$('animateRoutes').checked)return;function tick(now){if(!$('animateRoutes').checked)return;if(now-lastMotion>33){routeMotion+=.004;for(const o of routesRoot.children)placeArrowheads(o,routeMotion);render();lastMotion=now;}requestAnimationFrame(tick);}requestAnimationFrame(tick);};
window.analysisMode={getState:()=>({model:data?.name,mode,style,routes:routes.map(r=>({name:r.name,points:r.points.length,source:r.source})),meshes:modelMeshes.length,diagnostics}),loadData,importFiles,autoRoutes,exportSix,makeJimengPacket,projectData,restoreProject};
async function autoDeliver(){
  const requested=new URLSearchParams(location.search).get('export');if(!requested)return;
  if(requested!=='images'&&requested!=='all')throw Error('不支持的自动出图类型。');
  await autoRoutes();
  await emitFile(`空间流线_${FLOW_PAGES[flowPage].title}_${level().label}.png`,await blobOf(analysisCanvas()),false);
  await exportSvg();
  if(!featurePrepared.massing)buildMassing();
  for(let stage=2;stage<=5;stage++)if(!massingSession.getSelected(stage)){const candidate=massingSession.select(stage,0);const label=candidate.operationLabel||candidate.operation?.label||candidate.title;data.massingSteps[stage-1]={title:label,note:candidate.operation?.summary||`${label}，形成 ${blockCountLabel(candidate)}。`,autoGenerated:true};}
  rebuildSelectedMassing();savedMassingChoices=massingSession.exportChoices();persist();
  diagnostics.automaticMassingDraft='第 1 格为固定长方体；自动出图在第 2 至第 5 格各选第一个操作候选作为示例草稿，用户可在网页重新选择。';
  await emitFile('分析图方案_'+data.name+'.json',new Blob([JSON.stringify(projectData())],{type:'application/json'}),false);
  await task(async()=>{await exportSix(true);if(requested==='all')await exportViews();});
  const before=JSON.stringify(routes);const saved=JSON.parse(JSON.stringify(projectData()));await restoreProject(saved);
  diagnostics.roundTrip={passed:before===JSON.stringify(routes),routes:routes.length,model:data.name};
  diagnostics.canvas={width:canvas.width,height:canvas.height};
  await emitFile('网页出图核验.json',new Blob([JSON.stringify(diagnostics,null,2)],{type:'application/json'}),false);
  await setMode('massing');toast('自动出图已完成：流线图、六宫格、阶段图和可恢复方案。');
}
async function boot(){const path=new URLSearchParams(location.search).get('import');if(!path){await loadSample();return;}const u=new URL(path,location.href);if(u.origin!==location.origin)throw Error('只读取本机工作目录中的导入文件。');const names=await (await fetch(u)).json(),files=[];for(const name of names){const url=new URL(name,u);if(url.origin!==location.origin)throw Error('关联模型文件必须位于本机。');files.push(new File([await(await fetch(url)).blob()],name.split('/').at(-1)));}await importFiles(files);}
let bootResolved=false,pendingFeature=null;
window.addEventListener('message',event=>{
  if(event.origin!==location.origin||event.source!==window.parent||!event.data)return;
  if(event.data.type==='analysis-feature-pause'){$('animateRoutes').checked=false;stopEvolution();return;}
  if(event.data.type!=='analysis-feature-select'||!['flow','explode','massing'].includes(event.data.feature))return;
  if(!bootResolved){pendingFeature=event.data.feature;return;}
  selectFeature(event.data.feature);
});
setBusy(true,'正在读取当前模型…');boot().then(async()=>{
  resize();const requested=pendingFeature||new URLSearchParams(location.search).get('feature');
  const feature=['flow','explode','massing'].includes(requested)?requested:'massing';
  await selectFeature(feature,{autoGenerate:!!requested});bootResolved=true;
  if(pendingFeature&&pendingFeature!==feature)await selectFeature(pendingFeature);
  await autoDeliver();
}).catch(e=>{$('loading').hidden=false;$('loading').textContent=e.message;diagnostics.errors.push(e.message)});

// Live six-stage viewer: one demand-driven WebGL renderer, six independent cameras.
// The 2D canvases are live presentation surfaces, never precomputed image elements.
function ensureLiveRenderer(){
  if(liveRenderer)return;
  liveRenderer=new THREE.WebGLRenderer({antialias:true,alpha:false,preserveDrawingBuffer:true});
  liveRenderer.setPixelRatio(1);liveRenderer.setClearColor(0xffffff);
  liveRenderer.outputColorSpace=THREE.SRGBColorSpace;liveRenderer.toneMapping=THREE.ACESFilmicToneMapping;liveRenderer.toneMappingExposure=.88;
}
function sourcePresentation(){
  const group=new THREE.Group();
  for(const src of modelMeshes){
    const material=meshMaterial(src.userData.role);material.clippingPlanes=[];
    material.vertexColors=!!src.geometry.getAttribute('color');material.color.set(material.vertexColors?'#ffffff':src.userData.baseColor);
    material.opacity=src.userData.role==='glass'?.13:1;material.transparent=src.userData.role==='glass';material.depthWrite=!material.transparent;
    const mesh=new THREE.Mesh(src.geometry,material);mesh.userData.sharedGeometry=true;group.add(mesh);
  }
  return group;
}
function viewPose(v){return {position:v.camera.position.toArray(),target:v.controls.target.toArray(),up:v.camera.up.toArray(),span:v.camera.top-v.camera.bottom,zoom:v.camera.zoom};}
function applyViewPose(v,p){v.camera.position.fromArray(p.position);v.camera.up.fromArray(p.up||[0,0,1]);v.controls.target.fromArray(p.target);v.camera.top=p.span/2;v.camera.bottom=-p.span/2;v.camera.zoom=p.zoom||1;v.camera.lookAt(v.controls.target);v.controls.update();}
function saveLiveViews(){if(!data||!liveViews.length)return;data.massingViews={sync:liveSync,active:liveActive,cameras:liveViews.map(viewPose)};persist();}
function disposeLiveViews(){cancelAnimationFrame(liveRaf);liveRaf=0;for(const v of liveViews){v.observer.disconnect();v.controls.dispose();clearGroup(v.root);if(v.editOverlay)clearGroup(v.editOverlay);}liveViews=[];}
function fitLiveView(v){
  const box=boundsBox(true),c=box.getCenter(new THREE.Vector3()),delta=c.clone().sub(v.controls.target);v.camera.position.add(delta);v.controls.target.copy(c);v.camera.lookAt(c);v.camera.updateMatrixWorld();
  let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
  for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z]){const p=new THREE.Vector3(x,y,z).applyMatrix4(v.camera.matrixWorldInverse);minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y);}
  const aspect=Math.max(1,v.canvas.clientWidth)/Math.max(1,v.canvas.clientHeight),h=Math.max(maxY-minY,(maxX-minX)/aspect)*1.12;
  v.camera.top=h/2;v.camera.bottom=-h/2;v.camera.zoom=1;v.camera.updateProjectionMatrix();
}
function selectLiveView(i){liveActive=i;$('activeMassing').textContent=`当前第 ${i+1} 格`;$('stepSelect').value=String(i);liveViews.forEach((v,j)=>v.card.classList.toggle('active',i===j));updateMassingEditor();}
function syncLivePose(from){liveChanging=true;const pose=viewPose(from);for(const v of liveViews)if(v!==from)applyViewPose(v,pose);liveChanging=false;}
function requestLiveRender(){if(liveRaf)return;liveRaf=requestAnimationFrame(()=>{liveRaf=0;if(mode!=='massing'||evolving||document.hidden)return;for(const v of liveViews)drawLiveView(v);});}
function renderLiveImage(v,w,h){
  ensureLiveRenderer();
  // Fit a temporary export camera to every stage, retaining the chosen direction.
  const c=v.camera.clone(),box=boundsBox(true),center=box.getCenter(new THREE.Vector3());
  c.position.add(center.clone().sub(v.controls.target));c.lookAt(center);c.updateMatrixWorld();
  let width=0,height=0;
  for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z]){const p=new THREE.Vector3(x,y,z).applyMatrix4(c.matrixWorldInverse);width=Math.max(width,Math.abs(p.x)*2);height=Math.max(height,Math.abs(p.y)*2);}
  const span=Math.max(height,width*h/w)*1.18;c.top=span/2;c.bottom=-span/2;c.left=-span*w/h/2;c.right=span*w/h/2;c.zoom=1;c.updateProjectionMatrix();
  const overlayVisible=v.editOverlay?.visible;if(v.editOverlay)v.editOverlay.visible=false;
  try{liveRenderer.setSize(w,h,false);liveRenderer.render(v.scene,c);const out=document.createElement('canvas');out.width=w;out.height=h;out.getContext('2d').drawImage(liveRenderer.domElement,0,0);return out;}
  finally{if(v.editOverlay)v.editOverlay.visible=overlayVisible;}
}
function drawLiveView(v){
  const r=v.canvas.getBoundingClientRect();if(r.width<1||r.height<1)return;
  const ratio=Math.min(devicePixelRatio,1.5),w=Math.round(r.width*ratio),h=Math.round(r.height*ratio);
  if(v.canvas.width!==w||v.canvas.height!==h){v.canvas.width=w;v.canvas.height=h;}
  const ctx=v.canvas.getContext('2d');
  if(!v.root.children.length){ctx.drawImage(placeholderImage(w,h,v.index+1),0,0);return;}
  const c=v.camera,span=c.top-c.bottom;c.left=-span*w/h/2;c.right=span*w/h/2;c.updateProjectionMatrix();
  liveRenderer.setSize(w,h,false);liveRenderer.render(v.scene,c);ctx.drawImage(liveRenderer.domElement,0,0);
  // DOM diagnostics expose camera state for transparent interaction verification.
  v.canvas.dataset.camera=JSON.stringify(viewPose(v));v.canvas.dataset.editable=String(editEnabled&&v.index>=1&&v.index<=4);v.canvas.dataset.selectedPart=editEnabled&&v.index===liveActive?editPartId||'':'';v.canvas.dataset.renderCount=String(Number(v.canvas.dataset.renderCount||0)+1);
}
function rebuildLiveViews(){
  const saved=liveViews.length?{sync:liveSync,active:liveActive,cameras:liveViews.map(viewPose)}:data.massingViews;
  disposeLiveViews();ensureLiveRenderer();const grid=$('sixGrid');grid.replaceChildren();
  liveSync=saved?.sync!==false;liveActive=Math.max(0,Math.min(5,saved?.active||0));
  for(let i=0;i<6;i++){
    const d=story(i+1),card=document.createElement('div');card.className='step-card';card.dataset.step=i;
    const surface=document.createElement('canvas');surface.className='step-model';surface.tabIndex=0;surface.setAttribute('aria-label',`第${i+1}步 ${d.title} 三维模型，可拖动旋转`);card.append(surface);
    const caption=document.createElement('div');caption.className='step-caption';caption.setAttribute('role','button');caption.tabIndex=0;caption.setAttribute('aria-label',`编辑第${i+1}步说明`);caption.innerHTML=`<b><em>0${i+1}</em>${escapeHtml(d.title||'待生成')}</b><small>${escapeHtml(d.english||'FORM OPERATION')}</small><p>${escapeHtml(d.reason||'点击生成六步补齐此阶段。')}</p>`;card.append(caption);grid.append(card);
    const cs=new THREE.Scene();cs.add(new THREE.AmbientLight(0xffffff,1.7));const key=new THREE.DirectionalLight(0xffffff,2.3);key.position.set(-40,-60,100);cs.add(key);const fill=new THREE.DirectionalLight(0xd9e4e5,.8);fill.position.set(50,80,40);cs.add(fill);
    const candidate=i<5?massingSession.getSelected(i+1):null,root=i===5?sourcePresentation():candidate?makeCandidateGroup(candidate,true):new THREE.Group();cs.add(root);
    const cam=new THREE.OrthographicCamera(-40,40,35,-35,.1,2500);cam.up.set(0,0,1);const orbit=new OrbitControls(cam,surface);orbit.enableDamping=false;orbit.rotateSpeed=.55;orbit.minPolarAngle=.02;orbit.maxPolarAngle=Math.PI-.02;orbit.minZoom=.25;orbit.maxZoom=8;
    const center=boundsBox(true).getCenter(new THREE.Vector3());orbit.target.copy(center);cam.position.copy(center).add(new THREE.Vector3(-95,-115,86));cam.lookAt(center);
    const v={index:i,canvas:surface,card,root,scene:cs,camera:cam,controls:orbit};liveViews.push(v);
    fitLiveView(v);if(saved?.cameras?.[i])applyViewPose(v,saved.cameras[i]);
    orbit.addEventListener('start',()=>selectLiveView(i));orbit.addEventListener('change',()=>{if(liveChanging)return;if(liveSync)syncLivePose(v);requestLiveRender();});orbit.addEventListener('end',saveLiveViews);
    surface.addEventListener('pointerdown',e=>beginEditDrag(e,v),true);
    surface.addEventListener('pointerdown',()=>selectLiveView(i));
    surface.addEventListener('pointermove',moveEditDrag);surface.addEventListener('pointerup',finishEditDrag);surface.addEventListener('pointercancel',cancelEditDrag);
    const edit=()=>{selectLiveView(i);updateStepEditor();updateCandidatePanel();const folder=$('stepReason').closest('details');folder.open=true;folder.closest('[data-feature-tree]').open=true;};caption.onclick=edit;caption.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();edit();}};
    v.observer=new ResizeObserver(requestLiveRender);v.observer.observe(surface);
  }
  selectLiveView(liveActive);updateLiveModeButtons();applyEditInteraction();requestLiveRender();
}
function updateLiveModeButtons(){ $('syncMassing').setAttribute('aria-pressed',String(liveSync));$('soloMassing').setAttribute('aria-pressed',String(!liveSync));}
$('syncMassing').onclick=()=>{liveSync=true;if(liveViews.length)syncLivePose(liveViews[liveActive]);updateLiveModeButtons();requestLiveRender();saveLiveViews();};
$('soloMassing').onclick=()=>{liveSync=false;updateLiveModeButtons();saveLiveViews();};
$('alignMassing').onclick=()=>{if(liveViews.length)syncLivePose(liveViews[liveActive]);requestLiveRender();saveLiveViews();};
function resetLiveDirection(direction='iso'){liveChanging=true;for(const v of liveViews){const center=boundsBox(true).getCenter(new THREE.Vector3());v.controls.target.copy(center);v.camera.up.set(0,0,1);v.camera.position.copy(center).add(direction==='top'?new THREE.Vector3(0,-.01,200):new THREE.Vector3(-95,-115,86));v.camera.lookAt(center);fitLiveView(v);v.controls.update();}liveChanging=false;requestLiveRender();saveLiveViews();}
$('resetMassing').onclick=()=>resetLiveDirection();
$('exportMassingModel').onclick=()=>task(async()=>{
  const i=liveActive,candidate=massingSession?.getSelected(i+1);if(i<5&&!candidate)throw Error('请先生成本格体块。');
  const asset=i===5?sourcePresentation():makeCandidateGroup(candidate,false);
  // Export only model solids; dimension/operation guides stay in the analysis page.
  const extras=[];asset.traverse(o=>{if(o!==asset&&!o.isMesh&&o.type!=='Group')extras.push(o);});extras.forEach(o=>{o.parent?.remove(o);o.geometry?.dispose();o.material?.dispose();});
  asset.name=`阶段${i+1}_${story(i+1).title}`;asset.userData={stage:i+1,unit:'metre',reason:story(i+1).reason,sourceStatus:'空间解释体块，非施工模型'};
  const wrapper=new THREE.Group();wrapper.rotation.x=-Math.PI/2;wrapper.add(asset);wrapper.updateMatrixWorld(true);
  try{const glb=await new GLTFExporter().parseAsync(wrapper,{binary:true,onlyVisible:true});await emitFile(`体块阶段_${i+1}_${story(i+1).title}.glb`,new Blob([glb],{type:'model/gltf-binary'}));toast(`第 ${i+1} 阶段模型已导出，可单独引用；单位为米。`);}finally{clearGroup(asset);}
});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)requestLiveRender();});

// Box editing is explicit, local to a selected intermediate stage, and reversible.
function editorSnapshot(){return JSON.parse(JSON.stringify({steps:data.massingSteps,rounds:candidateRounds,part:editPartId,active:liveActive}));}
function restoreEditorSnapshot(s){data.massingSteps=s.steps;candidateRounds=s.rounds;editPartId=s.part;liveActive=s.active;$('stepSelect').innerHTML=data.massingSteps.map((d,i)=>`<option value="${i}">0${i+1} ${escapeHtml(d.title)}</option>`).join('');$('stepSelect').value=String(liveActive);}
function trackGeometryAction(fn){const before=JSON.stringify(massingSession.exportChoices()),ui=editorSnapshot(),result=fn();if(before!==JSON.stringify(massingSession.exportChoices())){editUndoUI.push(ui);if(editUndoUI.length>50)editUndoUI.shift();editRedoUI=[];}return result;}
function selectedEditPart(){return massingSession?.getSelected(liveActive+1)?.parts.find(p=>p.partId===editPartId&&p.kind==='box');}
function applyEditInteraction(){for(const v of liveViews){v.controls.enableRotate=!editEnabled;v.controls.enablePan=!editEnabled;v.canvas.dataset.editable=String(editEnabled&&v.index>=1&&v.index<=4);}requestLiveRender();}
function setMassingEditing(value){cancelEditDrag();editEnabled=!!value&&mode==='massing';$('massingEditor').hidden=!editEnabled;document.querySelector('article').classList.toggle('massing-editing',editEnabled);$('toggleMassingEditor').setAttribute('aria-pressed',String(editEnabled));$('toggleMassingEditor').textContent=editEnabled?'结束编辑':'编辑体块';applyEditInteraction();updateMassingEditor();}
function updateMassingEditor(){
  if(!$('editStage'))return;const stage=liveActive+1,candidate=massingSession?.getSelected(stage),parts=(candidate?.parts||[]).filter(p=>p.kind==='box');
  $('editStage').value=String(stage);const unlocked=stage>=2&&stage<=5,available=unlocked&&parts.length>0;
  if(!parts.some(p=>p.partId===editPartId))editPartId=available?parts[0].partId:null;
  $('editFields').disabled=!available;$('editPart').innerHTML=parts.map((p,i)=>`<option value="${escapeHtml(p.partId)}">体块 ${i+1}${p.manual?' · 已修改':''}</option>`).join('');$('editPart').value=editPartId||'';
  const part=selectedEditPart();if(part)for(const [axis,id] of ['sizeX','sizeY','sizeZ'].entries())$(id).value=Number((part.bounds[1][axis]-part.bounds[0][axis]).toFixed(4));
  $('editStatus').textContent=!unlocked?`第 ${stage} 格已锁定。请选择第 2—5 格。`:!candidate?'这一阶段待生成，请先点“生成六步”。':!parts.length?'此阶段不是可推拉的长方体，请由 AI 适配为分析体块。':`第 ${stage} 格 · ${parts.length} 个可编辑体块${candidate.manuallyEdited?' · 已手动调整':''}`;
  $('undoMassingEdit').disabled=!editUndoUI.length||!massingSession?.canUndo();$('redoMassingEdit').disabled=!editRedoUI.length||!massingSession?.canRedo();
  $('pushPullMode').setAttribute('aria-pressed',String(editTool==='push-pull'));$('moveBlockMode').setAttribute('aria-pressed',String(editTool==='translate'));$('pushPullFields').hidden=editTool!=='push-pull';$('moveFields').hidden=editTool!=='translate';
  document.querySelectorAll('[data-edit-face]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.editFace===`${editAxis},${editSide}`)));
  $('dragEditHint').textContent=editTool==='push-pull'?'按住一个模型面沿箭头拖动；Esc 取消。数值按导入后的模型单位，须先核对尺度。':'按住体块沿所选轴拖动；Esc 取消。移动保持尺寸不变。数值按导入后的模型单位。';
  updateEditOverlay();
}
function updateEditOverlay(boundsOverride){
  for(const v of liveViews){if(!v.editOverlay){v.editOverlay=new THREE.Group();v.scene.add(v.editOverlay);}clearGroup(v.editOverlay);v.editOverlay.visible=editEnabled&&v.index===liveActive;}
  const v=liveViews[liveActive],part=selectedEditPart();if(!editEnabled||!v||!part)return requestLiveRender();
  const bounds=boundsOverride||part.bounds,lo=vec(bounds[0]),hi=vec(bounds[1]),size=hi.clone().sub(lo),center=lo.clone().add(hi).multiplyScalar(.5);
  const box=new THREE.BoxGeometry(size.x,size.y,size.z),edge=new THREE.EdgesGeometry(box);box.dispose();const lines=new THREE.LineSegments(edge,new THREE.LineBasicMaterial({color:0xd45632,depthTest:false}));lines.position.copy(center);lines.renderOrder=20;v.editOverlay.add(lines);
  const axis=editTool==='translate'?Number($('moveAxis').value):editAxis,side=editTool==='translate'?1:editSide,normal=new THREE.Vector3().setComponent(axis,side),faceCenter=center.clone().setComponent(axis,(side>0?hi:lo).getComponent(axis));
  if(editTool==='push-pull'){const other=[0,1,2].filter(i=>i!==axis),face=new THREE.Mesh(new THREE.PlaneGeometry(size.getComponent(other[0]),size.getComponent(other[1])),new THREE.MeshBasicMaterial({color:0xffb66e,transparent:true,opacity:.32,side:THREE.DoubleSide,depthTest:false,depthWrite:false}));
    // Orient local plane axes explicitly so non-square faces match their dimensions.
    const u=new THREE.Vector3().setComponent(other[0],1),w=new THREE.Vector3().setComponent(other[1],1),n=u.clone().cross(w);face.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(u,w,n));face.position.copy(faceCenter);face.renderOrder=21;v.editOverlay.add(face);}
  const length=Math.max(.3,Math.min(2,Math.max(size.x,size.y,size.z)*.22)),arrow=new THREE.ArrowHelper(normal,faceCenter,length,0xd45632,length*.24,length*.12);arrow.traverse(o=>{if(o.material){o.material.depthTest=false;o.material.depthWrite=false;}o.renderOrder=22;});v.editOverlay.add(arrow);requestLiveRender();
}
async function refreshAfterGeometry({fit=false}={}){savedMassingChoices=massingSession.exportChoices();syncSelectedMassingSteps();rebuildSelectedMassing();persist();await refreshGrid();if(fit){liveChanging=true;liveViews.forEach(fitLiveView);liveChanging=false;saveLiveViews();}updateStepEditor();updateCandidatePanel();updateMassingEditor();reportFeature('massing');requestLiveRender();}
async function commitPartEdit(edit){const stage=liveActive+1;if(stage<2||stage>5||!selectedEditPart())throw Error('只可编辑第 2—5 格中的长方体。');const before=JSON.stringify(massingSession.exportChoices());trackGeometryAction(()=>massingSession.editPart(stage,editPartId,edit));if(before===JSON.stringify(massingSession.exportChoices()))return;await refreshAfterGeometry({fit:true});toast(`第 ${stage} 格体块已修改${stage<5?'；后续阶段待生成，可撤销恢复。':'；原始模型保持不变。'} 请核对图文说明。`);}
function numericValue(id){const raw=$(id).value.trim(),value=Number(raw);if(!raw||!Number.isFinite(value))throw Error('请输入有效数字。');return value;}
function replaceLiveCandidate(v,candidate){v.scene.remove(v.root);clearGroup(v.root);v.root=makeCandidateGroup(candidate,true);v.scene.add(v.root);requestLiveRender();}
function beginEditDrag(event,v){
  if(!editEnabled||event.button!==0)return;event.preventDefault();event.stopImmediatePropagation();if(editDrag)cancelEditDrag();selectLiveView(v.index);
  if(v.index<1||v.index>4){toast('第 1 格与第 6 格已锁定。');return;}
  const rect=v.canvas.getBoundingClientRect(),ray=new THREE.Raycaster();v.camera.updateMatrixWorld();v.scene.updateMatrixWorld(true);ray.setFromCamera(new THREE.Vector2((event.clientX-rect.left)/rect.width*2-1,-(event.clientY-rect.top)/rect.height*2+1),v.camera);
  const hit=ray.intersectObjects(v.root.children,true).find(h=>h.object.isMesh&&h.object.userData.partKind==='box');if(!hit){toast('请点击一个长方体的表面。');return;}
  editPartId=hit.object.userData.partId;const normal=hit.face.normal.clone().transformDirection(hit.object.matrixWorld);editAxis=[0,1,2].sort((a,b)=>Math.abs(normal.getComponent(b))-Math.abs(normal.getComponent(a)))[0];editSide=Math.sign(normal.getComponent(editAxis));updateMassingEditor();
  const axis=editTool==='translate'?Number($('moveAxis').value):editAxis,side=editTool==='translate'?1:editSide,direction=new THREE.Vector3().setComponent(axis,side),a=hit.point.clone().project(v.camera),b=hit.point.clone().add(direction).project(v.camera),dx=(b.x-a.x)*rect.width/2,dy=-(b.y-a.y)*rect.height/2;
  if(dx*dx+dy*dy<.3){toast('这个方向正对镜头，请用距离输入框，或退出编辑后转动视角。');return;}
  editDrag={v,pointerId:event.pointerId,start:[event.clientX,event.clientY],dx,dy,axis,side,tool:editTool,distance:0,valid:true,moved:false,partId:editPartId};v.canvas.setPointerCapture(event.pointerId);
}
function moveEditDrag(event){
  const d=editDrag;if(!d||event.pointerId!==d.pointerId)return;event.preventDefault();
  const sx=event.clientX-d.start[0],sy=event.clientY-d.start[1];if(Math.hypot(sx,sy)<3&&!d.moved)return;d.moved=true;
  let distance=(sx*d.dx+sy*d.dy)/(d.dx*d.dx+d.dy*d.dy),snap=Number($('editSnap').value);if(Number.isFinite(snap)&&snap>=.01)distance=Math.round(distance/snap)*snap;distance=Math.round(distance*10000)/10000;
  const delta=[0,0,0];delta[d.axis]=distance;const edit=d.tool==='translate'?{type:'translate',delta}:{type:'push-pull',axis:d.axis,side:d.side,distance};
  try{const preview=massingSession.previewEditPart(d.v.index+1,d.partId,edit);d.distance=distance;d.edit=edit;d.valid=true;replaceLiveCandidate(d.v,preview);updateEditOverlay(preview.parts.find(p=>p.partId===d.partId).bounds);$('editStatus').textContent=`${d.tool==='translate'?'移动':'推拉'} ${distance.toFixed(2)} · 松开应用，Esc 取消`;}
  catch(error){d.valid=false;$('editStatus').textContent=error.message;}
}
function releaseEditPointer(d){try{if(d.v.canvas.hasPointerCapture(d.pointerId))d.v.canvas.releasePointerCapture(d.pointerId);}catch{}}
function finishEditDrag(event){const d=editDrag;if(!d||event.pointerId!==d.pointerId)return;editDrag=null;releaseEditPointer(d);if(!d.moved||!d.valid||!d.edit||Math.abs(d.distance)<1e-8){replaceLiveCandidate(d.v,massingSession.getSelected(d.v.index+1));updateMassingEditor();return;}task(()=>commitPartEdit(d.edit));}
function cancelEditDrag(){const d=editDrag;if(!d)return;editDrag=null;releaseEditPointer(d);const candidate=massingSession?.getSelected(d.v.index+1);if(candidate&&liveViews.includes(d.v))replaceLiveCandidate(d.v,candidate);updateMassingEditor();}
$('toggleMassingEditor').onclick=()=>setMassingEditing(!editEnabled);$('closeMassingEditor').onclick=()=>setMassingEditing(false);
$('editStage').onchange=()=>{cancelEditDrag();editPartId=null;selectLiveView(Number($('editStage').value)-1);liveViews[liveActive]?.card.scrollIntoView({block:'nearest'});updateStepEditor();};
$('editPart').onchange=()=>{cancelEditDrag();editPartId=$('editPart').value;updateMassingEditor();};
document.querySelectorAll('[data-edit-face]').forEach(b=>b.onclick=()=>{[editAxis,editSide]=b.dataset.editFace.split(',').map(Number);updateMassingEditor();});
$('pushPullMode').onclick=()=>{cancelEditDrag();editTool='push-pull';updateMassingEditor();};$('moveBlockMode').onclick=()=>{cancelEditDrag();editTool='translate';updateMassingEditor();};$('moveAxis').onchange=()=>updateEditOverlay();
$('applyPull').onclick=()=>task(()=>commitPartEdit({type:'push-pull',axis:editAxis,side:editSide,distance:numericValue('pullDistance')}));
$('applyMove').onclick=()=>task(()=>{const delta=[0,0,0];delta[Number($('moveAxis').value)]=numericValue('moveDistance');return commitPartEdit({type:'translate',delta});});
$('applySize').onclick=()=>task(()=>{const part=selectedEditPart();if(!part)throw Error('请先选择一个体块。');const sizes=['sizeX','sizeY','sizeZ'].map(numericValue),lo=[...part.bounds[0]];return commitPartEdit({type:'set-bounds',bounds:[lo,lo.map((n,i)=>n+sizes[i])]});});
async function restoreEditHistory(redo=false){cancelEditDrag();const from=redo?editRedoUI:editUndoUI,to=redo?editUndoUI:editRedoUI;if(!from.length)return;const now=editorSnapshot();if(!(redo?massingSession.redo():massingSession.undo()))return;to.push(now);restoreEditorSnapshot(from.pop());await refreshAfterGeometry({fit:true});toast(redo?'已重做体块修改。':'已撤销，体块与后续阶段已一起恢复。');}
$('undoMassingEdit').onclick=()=>task(()=>restoreEditHistory());$('redoMassingEdit').onclick=()=>task(()=>restoreEditHistory(true));
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&editDrag){event.preventDefault();cancelEditDrag();toast('已取消本次拖动。');}});
