// Geometry-supported single-floor routing. Coordinates remain in model metres.
export function buildGrid(meshes, bounds, z, cell=.35, clearance=.25) {
  const x0=bounds[0][0]-.7,y0=bounds[0][1]-.7;
  const w=Math.ceil((bounds[1][0]-x0+.7)/cell),h=Math.ceil((bounds[1][1]-y0+.7)/cell);
  if(w*h>180000)throw Error('模型范围过大。请先核对导入单位，或只保留建筑范围。');
  const support=new Uint8Array(w*h),blocked=new Uint8Array(w*h);
  const idx=(x,y)=>y*w+x, cross=(a,b,p)=>(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]);
  function fill(a,b,c){
    let ix0=Math.max(0,Math.floor((Math.min(a[0],b[0],c[0])-x0)/cell)),ix1=Math.min(w-1,Math.ceil((Math.max(a[0],b[0],c[0])-x0)/cell));
    let iy0=Math.max(0,Math.floor((Math.min(a[1],b[1],c[1])-y0)/cell)),iy1=Math.min(h-1,Math.ceil((Math.max(a[1],b[1],c[1])-y0)/cell));
    for(let y=iy0;y<=iy1;y++)for(let x=ix0;x<=ix1;x++){
      const p=[x0+(x+.5)*cell,y0+(y+.5)*cell],s=[cross(a,b,p),cross(b,c,p),cross(c,a,p)];
      if(s.every(v=>v>=-1e-7)||s.every(v=>v<=1e-7))support[idx(x,y)]=1;
    }
  }
  function line(a,b){
    const r=clearance+cell*.4,ix0=Math.max(0,Math.floor((Math.min(a[0],b[0])-r-x0)/cell)),ix1=Math.min(w-1,Math.ceil((Math.max(a[0],b[0])+r-x0)/cell)),iy0=Math.max(0,Math.floor((Math.min(a[1],b[1])-r-y0)/cell)),iy1=Math.min(h-1,Math.ceil((Math.max(a[1],b[1])+r-y0)/cell));
    const dx=b[0]-a[0],dy=b[1]-a[1],d=dx*dx+dy*dy;
    for(let y=iy0;y<=iy1;y++)for(let x=ix0;x<=ix1;x++){
      const px=x0+(x+.5)*cell,py=y0+(y+.5)*cell,t=d?Math.max(0,Math.min(1,((px-a[0])*dx+(py-a[1])*dy)/d)):0;
      if((px-a[0]-t*dx)**2+(py-a[1]-t*dy)**2<r*r)blocked[idx(x,y)]=1;
    }
  }
  for(const mesh of meshes){
    const p=mesh.positions;
    for(let i=0;i<p.length;i+=9){
      const a=[p[i],p[i+1],p[i+2]],b=[p[i+3],p[i+4],p[i+5]],c=[p[i+6],p[i+7],p[i+8]],mn=Math.min(a[2],b[2],c[2]),mx=Math.max(a[2],b[2],c[2]);
      if(mx-mn<.12&&Math.abs((mn+mx)/2-z)<.38)fill(a,b,c);
      const probe=z+.85;
      if(mn<=probe&&mx>=probe&&mx-mn>.05){
        const pts=[];for(const [u,v] of [[a,b],[b,c],[c,a]])if((u[2]-probe)*(v[2]-probe)<0){const t=(probe-u[2])/(v[2]-u[2]);pts.push([u[0]+t*(v[0]-u[0]),u[1]+t*(v[1]-u[1])]);}
        if(pts.length===2)line(pts[0],pts[1]);
      }
    }
  }
  const walk=new Uint8Array(w*h);let count=0;
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){
    const k=idx(x,y);if(support[k]&&!blocked[k]&&support[k-1]&&support[k+1]&&support[k-w]&&support[k+w]){walk[k]=1;count++;}
  }
  return {x0,y0,w,h,cell,z,walk,count,supported:support.reduce((a,b)=>a+b,0),clearance};
}
export function findPath(g,start,end,maxSnap=1.75){
  const {x0,y0,w,h,cell,walk,z}=g;
  const point=k=>[x0+(k%w+.5)*cell,y0+(Math.floor(k/w)+.5)*cell,z+.28];
  function snap(p){let best=-1,dist=maxSnap*maxSnap;const cx=Math.floor((p[0]-x0)/cell),cy=Math.floor((p[1]-y0)/cell),n=Math.ceil(maxSnap/cell);for(let y=Math.max(0,cy-n);y<Math.min(h,cy+n+1);y++)for(let x=Math.max(0,cx-n);x<Math.min(w,cx+n+1);x++){const k=y*w+x;if(!walk[k])continue;const q=point(k),d=(q[0]-p[0])**2+(q[1]-p[1])**2;if(d<dist){dist=d;best=k;}}return best;}
  const a=snap(start),b=snap(end);if(a<0||b<0)return {ok:false,reason:'起点或终点附近没有可通行楼板，请调整位置或楼层标高。'};
  const n=w*h,score=new Float32Array(n).fill(Infinity),prev=new Int32Array(n).fill(-1),closed=new Uint8Array(n),heap=[];
  const heuristic=k=>Math.hypot(k%w-b%w,Math.floor(k/w)-Math.floor(b/w));
  function push(k,v){let i=heap.length;heap.push([k,v]);while(i){let p=(i-1)>>1;if(heap[p][1]<=v)break;heap[i]=heap[p];i=p;}heap[i]=[k,v];}
  function pop(){const first=heap[0],last=heap.pop();if(heap.length){let i=0;heap[0]=last;while(true){let l=i*2+1,r=l+1,j=i;if(l<heap.length&&heap[l][1]<heap[j][1])j=l;if(r<heap.length&&heap[r][1]<heap[j][1])j=r;if(j===i)break;[heap[i],heap[j]]=[heap[j],heap[i]];i=j;}}return first[0];}
  score[a]=0;push(a,heuristic(a));let visits=0;
  while(heap.length){const k=pop();if(closed[k])continue;closed[k]=1;visits++;if(k===b)break;const x=k%w,y=Math.floor(k/w);for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;let nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=w||ny>=h)continue;const j=ny*w+nx;if(!walk[j]||closed[j]||(dx&&dy&&(!walk[k+dx]||!walk[k+dy*w])))continue;const s=score[k]+(dx&&dy?Math.SQRT2:1);if(s<score[j]){score[j]=s;prev[j]=k;push(j,s+heuristic(j));}}}
  if(!closed[b])return {ok:false,reason:'没有找到连通路径。不会画穿墙直线，请更换终点或检查门洞。',visits};
  const cells=[];for(let k=b;k!==-1;k=prev[k]){cells.push(k);if(k===a)break;}cells.reverse();
  // Remove only collinear points. Do not smooth corners through walls or holes.
  const simple=[cells[0]];let oldDx=null,oldDy=null;
  for(let i=1;i<cells.length;i++){const dx=cells[i]%w-cells[i-1]%w,dy=Math.floor(cells[i]/w)-Math.floor(cells[i-1]/w);if(oldDx!==null&&(oldDx!==dx||oldDy!==dy))simple.push(cells[i-1]);oldDx=dx;oldDy=dy;}
  if(simple[simple.length-1]!==b)simple.push(b);
  return {ok:true,points:simple.map(point),cells,visits,length:score[b]*cell,snapStart:point(a),snapEnd:point(b)};
}
