// Four presentation categories across three lightweight flow pages.
// A room name is a hint, not proof of how the building is actually used.
export const FLOW_PAGES = Object.freeze({
  work: {title: '工作与会议', types: ['work', 'meeting'], description: '办公到达与会议往来分色显示。'},
  public: {title: '公共人行', types: ['public'], description: '入口、会客、公共平台等对外到达路径。'},
  vertical: {title: '楼层联系', types: ['vertical'], description: '已有楼梯路径的空间示意，不作疏散判定。'},
});

export const FLOW_TYPES = Object.freeze({
  public: {title: '公共人行', color: '#cb5946'},
  work: {title: '日常工作', color: '#367f9b'},
  meeting: {title: '会议往来', color: '#b27a2e'},
  vertical: {title: '上下楼交通', color: '#7966a5'},
  unclassified: {title: '待归类', color: '#73847c'},
});

export function inferFlowType(route) {
  if (route && Object.hasOwn(FLOW_TYPES, route.type)) return route.type;
  const reference = String(route?.referenceId || '');
  const name = String(route?.name || route?.text || '');
  if (/stairs?|楼梯|大阶梯|竖向|电梯|上下楼/i.test(reference + ' ' + name)) return 'vertical';
  if (/看台|会客|入口|人行|接待|大厅|平台|公共|展厅|门厅/.test(name)) return 'public';
  if (/会议|讨论|早会|报告|洽谈/.test(name)) return 'meeting';
  if (/办公|工作|工位|负责人|经理|Loft|出租|行政/.test(name)) return 'work';
  return 'unclassified';
}

export function flowMatchesPage(route, page) {
  return FLOW_PAGES[page]?.types.includes(inferFlowType(route)) || false;
}

// Keep every other floor and page intact when clearing the visible analysis.
export function routesAfterPageClear(routes, levelId, page) {
  if (!FLOW_PAGES[page] || levelId == null) return [...routes];
  return routes.filter(route => route.levelId !== levelId || !flowMatchesPage(route, page));
}

export function shouldAutoGenerateFlow({firstEntry,requested,cleared,hasRoomLabels,routeCount}) {
  return firstEntry && requested && !cleared && hasRoomLabels && routeCount === 0;
}
