// Keep authored grid paths intact. This module only chooses a smaller, safe
// set of points for drawing; every skipped span must stay inside walkable cells.
function cellIndex(g,p){
  const fx=(p[0]-g.x0)/g.cell-.5,fy=(p[1]-g.y0)/g.cell-.5;
  const x=Math.round(fx),y=Math.round(fy);
  if(Math.abs(fx-x)>1e-4||Math.abs(fy-y)>1e-4||x<0||y<0||x>=g.w||y>=g.h)return -1;
  return y*g.w+x;
}

export function gridSegmentClear(g,a,b){
  let x=a%g.w,y=Math.floor(a/g.w),endX=b%g.w,endY=Math.floor(b/g.w);
  if(a<0||b<0||a>=g.walk.length||b>=g.walk.length||!g.walk[a]||!g.walk[b])return false;
  const dx=endX-x,dy=endY-y,sx=Math.sign(dx),sy=Math.sign(dy);
  let tx=dx?0.5/Math.abs(dx):Infinity,ty=dy?0.5/Math.abs(dy):Infinity;
  const stepX=dx?1/Math.abs(dx):Infinity,stepY=dy?1/Math.abs(dy):Infinity;
  const valid=(cx,cy)=>cx>=0&&cy>=0&&cx<g.w&&cy<g.h&&!!g.walk[cy*g.w+cx];
  while(x!==endX||y!==endY){
    if(Math.abs(tx-ty)<1e-12){
      // A centre-to-centre line through a corner touches both side cells.
      // Requiring both avoids clipping wall corners or floor openings.
      if(!valid(x+sx,y)||!valid(x,y+sy))return false;
      x+=sx;y+=sy;tx+=stepX;ty+=stepY;
    }else if(tx<ty){x+=sx;tx+=stepX;}
    else{y+=sy;ty+=stepY;}
    if(!valid(x,y))return false;
  }
  return true;
}

export function simplifyGridRoute(g,points){
  if(!g||points.length<3)return points;
  const z=points[0][2];
  if(points.some(p=>Math.abs(p[2]-z)>.08))return points;
  const cells=points.map(p=>cellIndex(g,p));
  if(cells.some(k=>k<0||!g.walk[k]))return points;
  const result=[points[0]];
  let i=0;
  while(i<points.length-1){
    let next=i+1;
    for(let j=points.length-1;j>i+1;j--){
      if(gridSegmentClear(g,cells[i],cells[j])){next=j;break;}
    }
    result.push(points[next]);i=next;
  }
  return result;
}

export function levelLift(p,levelBases,levelIndex,explode,isFlat){
  const q=[...p];
  if(!explode||!levelBases.length)return q;
  if(isFlat){q[2]+=Math.max(0,levelIndex)*explode;return q;}
  // Cross-floor paths, such as stairs, stretch between shifted floor ends.
  // Their source coordinates are never changed.
  const z=p[2]-.28;
  let lo=0;
  while(lo<levelBases.length-1&&levelBases[lo+1]<=z)lo++;
  const hi=Math.min(lo+1,levelBases.length-1);
  const t=hi===lo?0:Math.max(0,Math.min(1,(z-levelBases[lo])/(levelBases[hi]-levelBases[lo])));
  q[2]+=explode*(lo+t);
  return q;
}
