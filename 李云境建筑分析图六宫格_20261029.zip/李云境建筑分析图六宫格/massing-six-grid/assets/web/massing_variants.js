// Generic explanatory massing; no project-specific geometry or claimed design history.
const SCHEMA = 'massing-editable-v5';
const LEGACY_SCHEMA = 'massing-source-grounded-v4';
const MIN_EDIT_SIZE = 0.01;
const MAX_HISTORY = 50;
const WHITE = '#e4e8df';
const OP_TYPES = ['split', 'cut-corner', 'add-corner'];
const copy = value => JSON.parse(JSON.stringify(value));
const round3 = n => Math.round(n * 1000) / 1000;
const extent = box => box[1].map((v, i) => v - box[0][i]);
const volume = box => extent(box).reduce((p, n) => p * Math.max(0, n), 1);
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const frac = n => n - Math.floor(n);

function hash(value) {
  const string = typeof value === 'string' ? value : JSON.stringify(value);
  let result = 2166136261;
  for (let i = 0; i < string.length; i++) {
    result ^= string.charCodeAt(i);
    result = Math.imul(result, 16777619);
  }
  return (result >>> 0).toString(36);
}

function validBounds(box) {
  if (!Array.isArray(box) || box.length !== 2 || box.some(row =>
    !Array.isArray(row) || row.length !== 3 || row.some(n => !Number.isFinite(Number(n))))) {
    throw new Error('体块分析需要有效的三维包络范围。');
  }
  const bounds = box.map(row => row.map(Number));
  if (bounds[0].some((n, i) => n > bounds[1][i])) throw new Error('体块包络范围上下界颠倒。');
  return bounds;
}

function positionsBounds(positions) {
  if (!positions || positions.length < 3) throw new Error('模型网格没有可读取的坐标。');
  const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i + 2 < positions.length; i += 3) for (let axis = 0; axis < 3; axis++) {
    const n = Number(positions[i + axis]);
    if (Number.isFinite(n)) {
      lo[axis] = Math.min(lo[axis], n);
      hi[axis] = Math.max(hi[axis], n);
    }
  }
  return validBounds([lo, hi]);
}

function boundsOf(mesh) {
  if (mesh.bounds) return validBounds(mesh.bounds);
  const box = mesh.geometry?.boundingBox;
  if (box) return validBounds([[box.min.x, box.min.y, box.min.z],
    [box.max.x, box.max.y, box.max.z]]);
  if (mesh.positions && typeof mesh.positions !== 'string') return positionsBounds(mesh.positions);
  throw new Error('网格缺少包络范围；请先计算 geometry.boundingBox。');
}

function unionBounds(boxes) {
  const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
  for (const box of boxes) for (let axis = 0; axis < 3; axis++) {
    lo[axis] = Math.min(lo[axis], box[0][axis]);
    hi[axis] = Math.max(hi[axis], box[1][axis]);
  }
  return [lo, hi];
}

function normalize(input) {
  if (!Array.isArray(input?.meshes) || !input.meshes.length) throw new Error('体块分析需要建筑网格。');
  const parts = input.meshes.flatMap((mesh, index) => {
    const role = String(mesh.role || mesh.userData?.role || 'building');
    if (role === 'site') return [];
    const sourceId = mesh.id ?? index;
    return [{kind: 'mesh', sourceId, sourceIds: [sourceId], bounds: boundsOf(mesh),
      role, levelIndex: mesh.levelIndex ?? mesh.userData?.levelIndex ?? 0,
      color: String(mesh.color || mesh.userData?.baseColor || WHITE)}];
  });
  if (!parts.length) throw new Error('模型仅包含场地，没有建筑网格。');
  const bounds = input.buildingBounds ? validBounds(input.buildingBounds)
    : unionBounds(parts.map(p => p.bounds));
  if (extent(bounds).some(n => n <= 0)) throw new Error('建筑包络缺少三维尺度，无法建立体块。');
  return {parts, bounds, sourceId: `MODEL-${hash(parts.map(p => [p.sourceId, p.bounds]))}`,
    architecture: null};
}

// A synchronous content signature, not a security/cryptographic checksum. Read
// all available coordinates without copying a potentially large typed array.
function sourceFingerprint(input, source) {
  let a = 2166136261, b = 2246822519;
  const feed = value => {
    const text = String(value);
    for (let i = 0; i < text.length; i++) {
      a = Math.imul(a ^ text.charCodeAt(i), 16777619);
      b = Math.imul(b ^ text.charCodeAt(i), 3266489917);
    }
    a = Math.imul(a ^ 255, 16777619); b = Math.imul(b ^ 255, 3266489917);
  };
  feed(input.sourceSha256 || ''); feed(input.name || '');
  feed(JSON.stringify(source.bounds));
  for (const [index, mesh] of input.meshes.entries()) {
    feed(index); feed(mesh.id ?? index); feed(mesh.role || mesh.userData?.role || 'building');
    feed(JSON.stringify(boundsOf(mesh))); feed(mesh.triangleCount ?? '');
    feed(mesh.color || mesh.userData?.baseColor || WHITE);
    const positions = mesh.positions ?? mesh.geometry?.getAttribute?.('position')?.array;
    if (positions && typeof positions !== 'string') {
      feed(positions.length); for (const value of positions) feed(value);
    } else feed(positions || 'bounds-only');
  }
  return `SOURCE-${(a >>> 0).toString(36)}-${(b >>> 0).toString(36)}`;
}

function editingBounds(source) {
  const size = extent(source.bounds);
  return [source.bounds[0].map((n, i) => n - size[i] * 2),
    source.bounds[1].map((n, i) => n + size[i] * 2)];
}

function checkedEditBounds(bounds, source) {
  if (!Array.isArray(bounds) || bounds.length !== 2 || bounds.some(row =>
    !Array.isArray(row) || row.length !== 3 || row.some(n => typeof n !== 'number' || !Number.isFinite(n)))) {
    throw new Error('编辑坐标必须是有限数字组成的两组三维坐标。');
  }
  if (extent(bounds).some(n => n < MIN_EDIT_SIZE - 1e-10)) {
    throw new Error(`体块每个方向的尺寸至少为 ${MIN_EDIT_SIZE} 模型单位，不能推穿对面。`);
  }
  const allowed = editingBounds(source);
  if (bounds.some((row, side) => row.some((n, axis) =>
    side === 0 ? n < allowed[0][axis] - 1e-10 : n > allowed[1][axis] + 1e-10))) {
    throw new Error('修改超出可编辑范围：每轴最多向源模型包络之外延伸原长的 2 倍。');
  }
  return copy(bounds);
}

function applyEditBounds(part, edit, source) {
  if (!edit || typeof edit !== 'object') throw new Error('缺少有效的体块编辑操作。');
  const bounds = copy(part.bounds);
  if (edit.type === 'push-pull') {
    if (!Number.isInteger(edit.axis) || edit.axis < 0 || edit.axis > 2 ||
      ![-1, 1].includes(edit.side) || typeof edit.distance !== 'number' || !Number.isFinite(edit.distance)) {
      throw new Error('推拉需要有效的轴、面方向以及有限数字距离。');
    }
    bounds[edit.side === 1 ? 1 : 0][edit.axis] += edit.side * edit.distance;
  } else if (edit.type === 'translate') {
    if (!Array.isArray(edit.delta) || edit.delta.length !== 3 ||
      edit.delta.some(n => typeof n !== 'number' || !Number.isFinite(n))) {
      throw new Error('移动量必须是三个有限数字。');
    }
    bounds.forEach(row => row.forEach((_, axis) => { row[axis] += edit.delta[axis]; }));
  } else if (edit.type === 'set-bounds') {
    return checkedEditBounds(edit.bounds, source);
  } else throw new Error('不支持的体块编辑操作。');
  return checkedEditBounds(bounds, source);
}

function fingerprint(parts) {
  return hash(parts.map(part => [part.kind, part.blockId,
    part.bounds.map(row => row.map(round3)), part.kind === 'plate' ? part.poly : null, part.riseAxis, part.color]));
}

function boxPart(bounds, parent, partId, blockId = parent.blockId) {
  return {kind: 'box', bounds: copy(bounds), sourceIds: [...parent.sourceIds],
    role: 'massing', levelIndex: 0, color: WHITE, partId, blockId};
}

function seedCandidate(source) {
  const outer = source.bounds, size = extent(outer);
  // The first simple mass remains inside the actual model envelope and leaves
  // room for later additive operations on all sides and above.
  const inset = [0.12, 0.17, 0];
  const bounds = [outer[0].map((n, i) => n + size[i] * inset[i]),
    outer[1].map((n, i) => i === 2 ? outer[0][2] + size[2] * 0.75 : n - size[i] * inset[i])];
  const part = {kind: 'box', bounds, sourceIds: source.parts.flatMap(p => p.sourceIds),
    role: 'massing', levelIndex: 0, color: WHITE, partId: 'seed', blockId: 'block-1'};
  const operation = {type: 'seed', label: '建立一个长方体',
    summary: '以原模型的建筑包络为依据，建立一个单一长方体作为体块母体。',
    source: source.sourceId, sourceBounds: copy(source.bounds), resultingBlockCount: 1};
  return {id: `S1-${hash([source.sourceId, bounds])}`, stage: 1, round: 0, index: 0,
    title: '单一长方体', note: operation.summary, operationLabel: operation.label,
    operation, operationHistory: [], parts: [part], blockCount: 1,
    complexity: {score: 1, target: 1, ratio: round3(1 / 6), operationCount: 0},
    derivedFrom: source.sourceId, fingerprint: fingerprint([part]), limitedDetail: false};
}

function sortedPartIndices(parts) {
  return parts.map((_, index) => index).sort((a, b) =>
    volume(parts[b].bounds) - volume(parts[a].bounds) || a - b);
}

function splitOperation(parent, stage, variant) {
  const parts = copy(parent.parts), indices = sortedPartIndices(parts);
  const targetIndex = indices[variant % Math.min(indices.length, 3)];
  const target = parts[targetIndex], size = extent(target.bounds);
  const horizontal = size[0] >= size[1] ? 0 : 1;
  const axis = variant % 3 === 1 ? 2 : variant % 3 === 2 ? 1 - horizontal : horizontal;
  const fraction = 0.42 + 0.16 * frac((variant + 1) * Math.SQRT2);
  const gap = size[axis] * (0.12 + (stage - 2) * 0.018 +
    0.04 * frac((variant + 1) * Math.sqrt(3)));
  const midpoint = target.bounds[0][axis] + size[axis] * fraction;
  const a = copy(target.bounds), b = copy(target.bounds);
  a[1][axis] = midpoint - gap / 2;
  b[0][axis] = midpoint + gap / 2;
  const first = boxPart(a, target, `${target.partId}/split-${stage}-${variant}-a`);
  const second = boxPart(b, target, `${target.partId}/split-${stage}-${variant}-b`,
    `block-${stage}-${variant}-${hash(parent.id)}`);
  parts.splice(targetIndex, 1, first, second);
  const axisName = ['东西', '南北', '竖向'][axis];
  const operation = {type: 'split', label: '分成两个体块',
    summary: `将现有体块沿${axisName}分为两个，留下清晰可见的分块间隙。`,
    targetPartId: target.partId, axis, gap: round3(gap),
    source: parent.id, resultingBlockCount: parent.blockCount + 1};
  return {parts, operation, blockCount: parent.blockCount + 1};
}

function cutCornerOperation(parent, stage, variant) {
  const parts = copy(parent.parts), indices = sortedPartIndices(parts);
  const targetIndex = indices[variant % Math.min(indices.length, 2)];
  const target = parts[targetIndex], bounds = target.bounds, size = extent(bounds);
  const corner = variant % 4, xHigh = !!(corner & 1), yHigh = !!(corner & 2);
  const xAmount = size[0] * (0.36 + 0.12 * frac((variant + 1) * Math.SQRT2));
  const yAmount = size[1] * (0.43 + 0.10 * frac((variant + 1) * Math.sqrt(3)));
  const first = copy(bounds), second = copy(bounds);
  // Two touching boxes form one conceptual L-shaped mass, with one corner
  // truly absent. The internal seam is an implementation detail, not a step.
  const xCut = xHigh ? bounds[1][0] - xAmount : bounds[0][0] + xAmount;
  if (xHigh) { first[1][0] = xCut; second[0][0] = xCut; }
  else { first[0][0] = xCut; second[1][0] = xCut; }
  if (yHigh) second[1][1] = bounds[1][1] - yAmount;
  else second[0][1] = bounds[0][1] + yAmount;
  const a = boxPart(first, target, `${target.partId}/cut-${stage}-${variant}-a`);
  const b = boxPart(second, target, `${target.partId}/cut-${stage}-${variant}-b`);
  parts.splice(targetIndex, 1, a, b);
  const cornerLabel = `${yHigh ? '北' : '南'}${xHigh ? '东' : '西'}`;
  const operation = {type: 'cut-corner', label: '切掉一个角',
    summary: `从现有体块的${cornerLabel}角切出一个明显的缺口，形成转折轮廓。`,
    targetPartId: target.partId, corner: cornerLabel,
    cutWidth: round3(xAmount), cutDepth: round3(yAmount),
    source: parent.id, resultingBlockCount: parent.blockCount};
  return {parts, operation, blockCount: parent.blockCount};
}

function intersectionVolume(a, b) {
  return [0, 1, 2].reduce((v, axis) =>
    v * Math.max(0, Math.min(a[1][axis], b[1][axis]) - Math.max(a[0][axis], b[0][axis])), 1);
}

function addCornerOperation(parent, stage, variant, sourceBounds, availableBounds = sourceBounds) {
  const existing = parent.parts;
  const sourceSize = extent(sourceBounds), options = [];
  const occupiedBounds = unionBounds(existing.map(part => part.bounds));
  for (const targetIndex of sortedPartIndices(existing)) {
    const target = existing[targetIndex], bounds = target.bounds, size = extent(bounds);
    for (const axis of [1, 0, 2]) for (const direction of [-1, 1]) {
      if (axis === 2 && direction < 0) continue;
      const margin = direction > 0 ? availableBounds[1][axis] - bounds[1][axis]
        : bounds[0][axis] - availableBounds[0][axis];
      const extension = Math.min(margin, sourceSize[axis] * (0.18 +
        0.075 * frac((variant + 1) * Math.SQRT2)));
      if (extension < sourceSize[axis] * 0.035) continue;
      const addition = copy(bounds);
      if (direction > 0) { addition[0][axis] = bounds[1][axis]; addition[1][axis] += extension; }
      else { addition[1][axis] = bounds[0][axis]; addition[0][axis] -= extension; }
      for (let other = 0; other < 3; other++) {
        if (other === axis) continue;
        const share = other === 2 ? 0.84 + 0.10 * frac((variant + 1) * Math.sqrt(5))
          : 0.67 + 0.16 * frac((variant + 1) * Math.sqrt(7));
        const span = size[other] * share;
        const atHigh = (variant + axis + other) % 2 === 0;
        if (atHigh) addition[0][other] = addition[1][other] - span;
        else addition[1][other] = addition[0][other] + span;
      }
      const newVolume = volume(addition);
      const overlapping = existing.reduce((total, part) =>
        total + intersectionVolume(addition, part.bounds), 0);
      const exposed = clamp(newVolume - overlapping, 0, newVolume);
      if (exposed / volume(parent.parts[0].bounds) < 0.028) continue;
      // A wing placed inside the gap between two existing masses can change
      // volume while barely changing the diagram's silhouette. Prefer an
      // addition extending the actual outside edge, especially the south or
      // west faces visible from the workbench's fixed south-west axonometric.
      const outward = direction > 0 ? Math.max(0, addition[1][axis] - occupiedBounds[1][axis])
        : Math.max(0, occupiedBounds[0][axis] - addition[0][axis]);
      const visibilityWeight = axis === 2 ? 1.25
        : direction < 0 ? (axis === 1 ? 1.55 : 1.35) : 0.65;
      const silhouetteGain = outward / sourceSize[axis] * visibilityWeight;
      options.push({targetIndex, addition, axis, direction, exposed,
        rank: silhouetteGain * 1.6 + 2.5 *
          exposed / Math.max(0.001, sourceSize[0] * sourceSize[1] * sourceSize[2])});
    }
  }
  options.sort((a, b) => b.rank - a.rank || a.axis - b.axis || a.direction - b.direction);
  if (!options.length) return null;
  const choice = options[variant % Math.min(options.length, 3)];
  const target = existing[choice.targetIndex], parts = copy(existing);
  parts.push(boxPart(choice.addition, target, `${target.partId}/add-${stage}-${variant}`));
  const side = choice.axis === 2 ? '顶部'
    : choice.axis === 0 ? (choice.direction > 0 ? '东侧' : '西侧')
      : (choice.direction > 0 ? '北侧' : '南侧');
  const operation = {type: 'add-corner', label: '补上一个角',
    summary: `在现有体块${side}补出一个附加角部，形成可辨认的外伸轮廓。`,
    targetPartId: target.partId, side, addedBounds: copy(choice.addition),
    source: parent.id, resultingBlockCount: parent.blockCount};
  return {parts, operation, blockCount: parent.blockCount};
}

function generateOperation(parent, type, stage, variant, source) {
  if (type === 'split') return splitOperation(parent, stage, variant);
  if (type === 'cut-corner') return cutCornerOperation(parent, stage, variant);
  return addCornerOperation(parent, stage, variant, source.bounds, parent.manual ? editingBounds(source) : source.bounds);
}

function candidateFor(parent, type, stage, round, index, variant, source) {
  const result = generateOperation(parent, type, stage, variant, source);
  if (!result) return null;
  const operation = {...result.operation, step: stage, modelSource: source.sourceId};
  const parts = result.parts, fp = fingerprint(parts);
  return {id: `S${stage}-R${round}-${hash(parent.id)}-V${index}-${fp}`,
    stage, round, index, title: operation.label, note: operation.summary,
    operationLabel: operation.label, operation,
    operationHistory: [...parent.operationHistory, operation],
    parts, blockCount: result.blockCount,
    complexity: {score: stage, target: stage, ratio: round3(stage / 6),
      operationCount: stage - 1},
    derivedFrom: parent.id, fingerprint: fp, limitedDetail: false,
    ...(parent.manual ? {manual: true, requiresReview: true, inheritedManual: true} : {})};
}

export function createMassingSession(input) {
  const source = normalize(input), cache = new Map(), selected = new Map();
  const sourceSignature = sourceFingerprint(input, source);
  const past = [], future = [];
  const snapshot = () => copy([...selected]);
  const loadSnapshot = state => { selected.clear(); for (const [stage, choice] of state) selected.set(stage, copy(choice)); };
  function transaction(work) {
    const before = snapshot();
    try {
      const result = work();
      if (JSON.stringify(before) !== JSON.stringify(snapshot())) {
        past.push(before); if (past.length > MAX_HISTORY) past.shift(); future.length = 0;
      }
      return result;
    } catch (error) { loadSnapshot(before); throw error; }
  }
  const seed = seedCandidate(source);
  selected.set(1, seed);
  const sourceCandidate = {id: source.sourceId, stage: 6, title: '完整彩色原模型',
    note: '最终揭示导入模型的完整形体、细部及原始基础颜色。',
    parts: copy(source.parts), blockCount: null,
    operation: {type: 'reveal-source', label: '揭示完整模型',
      summary: '最终揭示导入模型的完整形体、细部及原始基础颜色。',
      source: source.sourceId},
    operationLabel: '揭示完整模型', operationHistory: [],
    complexity: {score: 6, target: 6, ratio: 1, operationCount: 5}};

  function getCandidates(stage, round = 0) {
    if (!Number.isInteger(stage) || stage < 1 || stage > 5) throw new Error('体块阶段应为第 1 至第 5 格。');
    if (!Number.isInteger(round) || round < 0 || round > 100) throw new Error('候选组编号应为 0 至 100 的整数。');
    if (stage === 1) return [copy(seed)];
    const parent = selected.get(stage - 1);
    if (!parent) throw new Error(`请先选择第 ${stage - 1} 格，再生成第 ${stage} 格。`);
    const key = `${stage}:${round}:${parent.id}`;
    if (cache.has(key)) return copy(cache.get(key));
    const seen = new Set();
    for (let previous = 0; previous < round; previous++) {
      for (const candidate of getCandidates(stage, previous)) seen.add(candidate.fingerprint);
    }
    const candidates = [];
    for (let index = 0; index < 3; index++) {
      const type = OP_TYPES[index];
      let candidate = null;
      for (let attempt = 0; attempt < 96; attempt++) {
        const variant = round * 96 + attempt;
        const draft = candidateFor(parent, type, stage, round, index, variant, source);
        if (draft && !seen.has(draft.fingerprint)) { candidate = draft; break; }
      }
      // Manual edits may use all available room, making an addition impossible.
      // Keep the remaining real operations rather than blocking the whole stage.
      if (!candidate) continue;
      candidate.index = candidates.length;
      seen.add(candidate.fingerprint);
      candidates.push(candidate);
    }
    if (!candidates.length) throw new Error(`第 ${stage} 格没有可用的新操作，请调整上一格体块或选择较早的候选组。`);
    cache.set(key, candidates);
    return copy(candidates);
  }

  function selectInternal(stage, idOrIndex, round = 0) {
    if (typeof idOrIndex === 'string') {
      const match = /^S\d+-R(\d+)-/.exec(idOrIndex);
      if (match) round = Number(match[1]);
    }
    const choices = getCandidates(stage, round);
    const candidate = typeof idOrIndex === 'number' ? choices[idOrIndex]
      : choices.find(choice => choice.id === idOrIndex);
    if (!candidate) throw new Error('所选体块方案已失效；请重新生成这一阶段的候选。');
    const old = selected.get(stage);
    selected.set(stage, candidate);
    if (old?.id !== candidate.id) for (let later = stage + 1; later <= 5; later++) selected.delete(later);
    return copy(candidate);
  }

  function select(stage, idOrIndex, round = 0) {
    return transaction(() => selectInternal(stage, idOrIndex, round));
  }

  function previewEditPart(stage, partId, edit) {
    if (!Number.isInteger(stage) || stage < 2 || stage > 5) {
      throw new Error('只能编辑第 2 至第 5 格；第 1 格和第 6 格已锁定。');
    }
    const current = selected.get(stage);
    if (!current) throw new Error('请先生成并选用本格体块，再进行修改。');
    const targetIndex = current.parts.findIndex(part => part.partId === partId);
    if (targetIndex < 0) throw new Error('所选体块已失效，请重新选择。');
    const target = current.parts[targetIndex];
    if (target.kind !== 'box') throw new Error('当前仅支持长方体部件推拉，不能修改网格或非长方体部件。');
    const bounds = applyEditBounds(target, edit, source);
    if (JSON.stringify(bounds) === JSON.stringify(target.bounds)) return copy(current);
    if ((current.manualEdits?.length || 0) >= 256) throw new Error('本格已累计 256 次修改，请重新选用候选体块后再编辑。');
    const candidate = copy(current);
    candidate.parts[targetIndex].bounds = bounds;
    candidate.parts[targetIndex].manual = true;
    candidate.parts[targetIndex].requiresReview = true;
    candidate.manual = true; candidate.manuallyEdited = true; candidate.requiresReview = true;
    candidate.baseCandidateId = current.baseCandidateId || current.id;
    candidate.baseTitle = current.baseTitle || current.title;
    candidate.title = `${candidate.baseTitle} · 手动修改`;
    candidate.manualEdits = [...(current.manualEdits || []), {partId, edit: copy(edit)}];
    candidate.manualBeforeBounds = copy(target.bounds);
    candidate.manualPartIds = [...new Set([...(current.manualPartIds || []), partId])];
    candidate.fingerprint = fingerprint(candidate.parts);
    candidate.id = `${candidate.baseCandidateId}-E${candidate.manualEdits.length}-${hash([current.id, partId, edit, bounds])}`;
    const operation = {type: 'manual-edit', label: '手动修改体块', step: stage,
      summary: '已手动调整体块；修改后的空间理由及其与后续阶段的关系待核对。',
      source: current.id, modelSource: source.sourceId, targetPartId: partId, edit: copy(edit),
      beforeBounds: copy(target.bounds), afterBounds: copy(bounds), manual: true,
      resultingBlockCount: candidate.blockCount};
    candidate.operation = operation; candidate.operationLabel = operation.label;
    candidate.operationHistory = [...current.operationHistory, operation];
    candidate.note = operation.summary;
    return candidate;
  }

  function editInternal(stage, partId, edit) {
    const next = previewEditPart(stage, partId, edit), previous = selected.get(stage);
    if (next.id !== previous.id) {
      selected.set(stage, next);
      for (let later = stage + 1; later <= 5; later++) selected.delete(later);
    }
    return copy(next);
  }
  function editPart(stage, partId, edit) {
    return transaction(() => editInternal(stage, partId, edit));
  }
  function undo() {
    if (!past.length) return false;
    future.push(snapshot()); loadSnapshot(past.pop()); return true;
  }
  function redo() {
    if (!future.length) return false;
    past.push(snapshot()); loadSnapshot(future.pop()); return true;
  }

  function getSelected(stage) {
    if (stage === 6) return copy(sourceCandidate);
    return selected.has(stage) ? copy(selected.get(stage)) : null;
  }

  function exportChoices() {
    const result = {schema: SCHEMA, sourceFingerprint: sourceSignature};
    for (let stage = 1; stage <= 5; stage++) {
      const choice = selected.get(stage);
      if (choice) result[stage] = {round: choice.round, index: choice.index,
        ...(choice.manualEdits?.length ? {edits: copy(choice.manualEdits)} : {})};
    }
    return result;
  }

  function restoreChoices(saved = {}) {
    const before = snapshot();
    try {
      if (!saved || typeof saved !== 'object' || Array.isArray(saved)) throw new Error('体块选稿格式无效。');
      const hasData = Object.keys(saved).length > 0, legacy = saved.schema === LEGACY_SCHEMA;
      if (hasData && saved.schema !== SCHEMA && !legacy) throw new Error('体块选稿版本不兼容，请重新选择体块。');
      if (hasData && !legacy && saved.sourceFingerprint !== sourceSignature) {
        throw new Error('选稿绑定的源模型与当前模型不同，未应用任何编辑。');
      }
      if (saved[6] || saved[1]?.edits?.length || (legacy && Object.values(saved).some(v => v?.edits?.length))) {
        throw new Error('选稿包含锁定阶段或旧格式不支持的编辑，未恢复。');
      }
      selected.clear(); selected.set(1, seed);
      let gap = false;
      for (let stage = 2; stage <= 5; stage++) {
        const choice = saved[stage];
        if (!choice) { gap = true; continue; }
        if (gap) throw new Error('选稿的阶段链不完整，不能将后续编辑套用到不同母体。');
        if (!Number.isInteger(choice.index) || choice.index < 0 || choice.index > 2 ||
          !Number.isInteger(choice.round ?? 0) || (choice.round ?? 0) < 0 || (choice.round ?? 0) > 100) {
          throw new Error('选稿的候选编号或候选组编号无效。');
        }
        selectInternal(stage, choice.index, choice.round ?? 0);
        if (choice.edits !== undefined) {
          if (!Array.isArray(choice.edits) || choice.edits.length > 256) throw new Error('选稿的编辑记录无效。');
          for (const record of choice.edits) {
            if (!record || typeof record.partId !== 'string') throw new Error('选稿的体块编辑记录无效。');
            editInternal(stage, record.partId, record.edit);
          }
        }
      }
      past.length = 0; future.length = 0;
      return {...exportChoices(), ...(legacy ? {migrationWarning: '旧版 v4 未绑定源模型；已迁移，请核对模型与各阶段。'} : {})};
    } catch (error) { loadSnapshot(before); throw error; }
  }

  // Fill only missing stages. One undo restores the entire state before filling.
  function completeDraft() {
    return transaction(() => {
      let added = 0;
      for (let stage = 2; stage <= 5; stage++) if (!selected.has(stage)) {
        const available = getCandidates(stage, 0);
        selectInternal(stage, (stage - 2) % available.length, 0); added++;
      }
      return {added, grounded: false, choices: exportChoices()};
    });
  }
  function getDiagram(stage) {
    const current = getSelected(stage); if (!current) return null;
    const parent = stage > 1 && stage < 6 ? getSelected(stage - 1) : null;
    const b = source.bounds, mid = b[0].map((n,i)=>(n+b[1][i])/2);
    const narrative = [current.title,stage===1?'BASE VOLUME':stage===6?'SOURCE MODEL':'FORM OPERATION',stage===6?'完整源模型对照；前五格为通用表达草稿。':current.operation?.summary||'以单一母体概括总体范围。'];
    const result={title:narrative[0],english:narrative[1],reason:narrative[2],
      evidence:current.manual?'已手动修改 · 设计理由待核对':'通用草稿 · 设计理由待核对',outlines:[],arrows:[],highlightIds:[]};
    if(!parent) return result;
    const changed=current.parts.filter(p=>!parent.parts.some(q=>q.partId===p.partId&&JSON.stringify(q.bounds)===JSON.stringify(p.bounds)));
    {

      result.outlines=parent.parts.filter(p=>!current.parts.some(q=>q.partId===p.partId)).map(p=>p.bounds);
      if(current.manualBeforeBounds) result.outlines.push(copy(current.manualBeforeBounds));
      result.highlightIds=[...new Set([...changed.map(p=>p.partId),...(current.manualPartIds||[])])];
      const target=changed[0]?.bounds||parent.parts[0].bounds, c=target[0].map((n,i)=>(n+target[1][i])/2);
      result.arrows=[[[target[0][0]-1,c[1],c[2]],[target[0][0]+Math.min(3,(target[1][0]-target[0][0])*.3),c[1],c[2]]]];
    }
    return copy(result);
  }
  return {getCandidates, select, getSelected, exportChoices, restoreChoices, completeDraft, getDiagram,
    editPart, previewEditPart, undo, redo, canUndo: () => past.length > 0, canRedo: () => future.length > 0,
    getSourceSummary: () => ({bounds: copy(source.bounds), complexityScore: 6,
      meshCount: source.parts.length, sourceId: source.sourceId,
      sourceFingerprint: sourceSignature,
      editing: {stages: [2,3,4,5], minSize: MIN_EDIT_SIZE, bounds: editingBounds(source), units: 'model-units', historyLimit: MAX_HISTORY},
      generationRule: 'one-cuboid-then-one-operation-per-stage'})};
}
