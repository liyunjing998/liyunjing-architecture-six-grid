"""Create a recoverable local analysis workspace and print its browser URL."""
from pathlib import Path
import argparse, errno, filecmp, shutil, socket, subprocess, sys, json, urllib.request, urllib.parse, time

SUPPORTED={'.glb','.gltf','.obj','.stl','.json','.gz','.html'}

def model_files(model):
    if not model.is_file():raise SystemExit('找不到输入模型。')
    if model.suffix.lower() not in SUPPORTED:raise SystemExit('此格式不能直接导入。请从原软件导出 GLB、glTF、OBJ、STL 或受支持的 JSON/HTML。')
    resources=[]
    if model.suffix.lower()=='.gltf':
        try:
            data=json.loads(model.read_text())
            uris=[x.get('uri','') for x in data.get('buffers',[])+data.get('images',[])]
        except (OSError,ValueError,TypeError,AttributeError) as e:raise SystemExit('glTF 文件不是有效的 JSON：'+str(e))
        basenames=set()
        for uri in uris:
            if not uri or uri.startswith('data:'):continue
            parsed=urllib.parse.urlparse(uri)
            if parsed.scheme or parsed.netloc or parsed.query or parsed.fragment:raise SystemExit('glTF 关联资源须为模型目录内的本地文件。请导出单文件 GLB。')
            relative=Path(urllib.parse.unquote(parsed.path))
            resource=(model.parent/relative).resolve()
            if relative.is_absolute() or not resource.is_relative_to(model.parent) or not resource.is_file():raise SystemExit('glTF 关联资源缺失或位于模型目录之外。请导出单文件 GLB。')
            if resource.name in basenames:raise SystemExit('glTF 关联资源存在同名文件，网页无法区分。请导出单文件 GLB。')
            basenames.add(resource.name);resources.append((resource,relative))
    return resources

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--model',type=Path);p.add_argument('--port',type=int,default=8793);p.add_argument('--prepare-only',action='store_true');a=p.parse_args()
    template=Path(__file__).resolve().parents[1]/'assets/web';dest=a.output.resolve()
    if not template.is_dir():raise SystemExit('Skill网页资源不完整。')
    if dest.is_relative_to(template):raise SystemExit('输出目录不能放在 Skill 网页模板里面。')
    model=a.model.resolve() if a.model else None
    resources=model_files(model) if model else []
    dest.mkdir(parents=True,exist_ok=True)
    # A workspace is a copy, not a live link to a skill or source-model directory.
    for src in template.rglob('*'):
        if src.is_file():
            out=dest/src.relative_to(template)
            if not out.exists():out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,out)
    query='?feature=massing'
    if model:
        imported=dest/'data/imported';imported.mkdir(parents=True,exist_ok=True);target=imported/model.name
        if target.exists() and not filecmp.cmp(target,model,shallow=False):
            imported=imported/str(time.time_ns());imported.mkdir();target=imported/model.name
        if target!=model:shutil.copy2(model,target)
        names=[model.name]
        for resource,relative in resources:
            destfile=imported/relative;destfile.parent.mkdir(parents=True,exist_ok=True)
            if destfile!=resource:shutil.copy2(resource,destfile)
            names.append(relative.as_posix())
        manifest=imported/'files.json';manifest.write_text(json.dumps(names,ensure_ascii=False));query='?feature=massing&import='+urllib.parse.quote(str(manifest.relative_to(dest)))
    if a.prepare_only:print(dest);return
    for port in range(a.port,a.port+25):
        try:
            with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=.4) as r:health=json.load(r)
            if health.get('app')=='analysis-mode' and health.get('root')==str(dest):
                print(f'http://127.0.0.1:{port}/'+query);return
        except Exception:pass
        probe=socket.socket()
        try:probe.bind(('127.0.0.1',port));probe.close()
        except OSError as error:
            probe.close()
            if error.errno == errno.EADDRINUSE:continue
            if error.errno in (errno.EACCES,errno.EPERM):
                raise SystemExit('当前运行环境不允许监听本机端口；这不是端口占用。工作区已保留，请在有本机服务权限的终端运行，或由用户调整权限。')
            raise SystemExit('无法绑定本机服务端口：'+str(error))
        with open(dest/'server.log','a') as log:
            subprocess.Popen([sys.executable,str(dest/'serve.py'),'--port',str(port)],cwd=dest,stdout=log,stderr=log,start_new_session=True)
        for _ in range(30):
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=.3) as r:health=json.load(r)
                if health.get('app')=='analysis-mode' and health.get('root')==str(dest):print(f'http://127.0.0.1:{port}/'+query);return
            except Exception:time.sleep(.1)
        raise SystemExit('服务未能启动，请查看输出目录的 server.log。')
    raise SystemExit('没有找到空闲端口。')
if __name__=='__main__':main()
