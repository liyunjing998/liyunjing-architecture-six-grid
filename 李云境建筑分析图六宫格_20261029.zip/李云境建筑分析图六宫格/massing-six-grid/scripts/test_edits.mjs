import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createMassingSession} from '../assets/web/massing_variants.js';
const model=JSON.parse(fs.readFileSync(new URL('../assets/web/data/demo-building.analysis.json',import.meta.url)));
const sourceBefore=JSON.stringify(model), checks=[];
const fresh=()=>{const s=createMassingSession(model);s.completeDraft();s.restoreChoices(s.exportChoices());return s;};
const state=s=>Array.from({length:6},(_,i)=>s.getSelected(i+1));
const check=(name,fn)=>{fn();checks.push(name);};
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-9,`${a} != ${b}`);
const part=s=>s.getSelected(2).parts[0];

check('both faces on all three axes push/pull with outward-positive sign',()=>{
  for(const axis of [0,1,2])for(const side of [-1,1])for(const distance of [-0.05,0.05]){
    const s=fresh(),p=part(s),before=structuredClone(p.bounds);
    const result=s.editPart(2,p.partId,{type:'push-pull',axis,side,distance});
    close(result.parts[0].bounds[side===1?1:0][axis],before[side===1?1:0][axis]+side*distance);
    close(result.parts[0].bounds[side===1?0:1][axis],before[side===1?0:1][axis]);
    assert.equal(result.manual,true);assert.equal(result.parts[0].manual,true);
  }
});
check('preview changes geometry without selection, source, or undo mutation',()=>{
  const s=fresh(),before=state(s),p=part(s);
  const preview=s.previewEditPart(2,p.partId,{type:'translate',delta:[1,2,3]});
  close(preview.parts[0].bounds[0][0],p.bounds[0][0]+1);
  preview.parts[0].bounds[0][0]=9999;
  assert.deepEqual(state(s),before);assert.equal(s.canUndo(),false);
});
check('earlier edits invalidate dependents; regenerated candidates use new parent',()=>{
  const s=fresh(),p=part(s),old=s.getCandidates(3).map(c=>c.id),source=s.getSelected(6);
  const changed=s.editPart(2,p.partId,{type:'translate',delta:[1,0,0]});
  for(const stage of [3,4,5])assert.equal(s.getSelected(stage),null);
  assert.deepEqual(s.getSelected(6),source);
  for(const c of s.getCandidates(3)){assert.equal(c.derivedFrom,changed.id);assert.ok(!old.includes(c.id));assert.equal(c.manual,true);}
  s.completeDraft();assert.equal(s.getSelected(3).derivedFrom,changed.id);
});
check('undo and redo restore all later choices as a single state',()=>{
  const s=fresh(),before=state(s),p=part(s);
  s.editPart(2,p.partId,{type:'push-pull',axis:0,side:1,distance:0.4});const edited=state(s);
  assert.equal(s.canUndo(),true);assert.equal(s.undo(),true);assert.deepEqual(state(s),before);
  assert.equal(s.canRedo(),true);assert.equal(s.redo(),true);assert.deepEqual(state(s),edited);
});
check('select and fill-missing are distinct atomic history actions',()=>{
  const s=fresh(),before=state(s);s.select(2,1);const selected=state(s);
  assert.equal(s.completeDraft().added,3);const completed=state(s);
  s.undo();assert.deepEqual(state(s),selected);s.undo();assert.deepEqual(state(s),before);
  s.redo();assert.deepEqual(state(s),selected);s.redo();assert.deepEqual(state(s),completed);
});
check('no-op edits preserve selected dependents, history, and redo',()=>{
  const s=fresh(),before=state(s),p=part(s);
  s.editPart(2,p.partId,{type:'translate',delta:[0,0,0]});
  assert.deepEqual(state(s),before);assert.equal(s.canUndo(),false);
  s.editPart(2,p.partId,{type:'translate',delta:[1,0,0]});s.undo();
  s.editPart(2,p.partId,{type:'push-pull',axis:0,side:1,distance:0});
  assert.equal(s.canRedo(),true);assert.deepEqual(state(s),before);
  s.completeDraft();assert.equal(s.canRedo(),true);
});
check('new edit after undo discards redo branch',()=>{
  const s=fresh(),p=part(s);s.editPart(2,p.partId,{type:'translate',delta:[1,0,0]});s.undo();
  s.editPart(2,p.partId,{type:'translate',delta:[0,1,0]});assert.equal(s.canRedo(),false);
});
check('stages 1 and 6 are locked for edit and preview; missing and stale parts reject',()=>{
  const s=fresh(),before=state(s);
  for(const stage of [0,1,6,7,2.5])for(const method of ['editPart','previewEditPart']){
    assert.throws(()=>s[method](stage,'seed',{type:'translate',delta:[1,0,0]}),/锁定/);
  }
  assert.throws(()=>s.getCandidates(2,101),/100/);
  assert.throws(()=>s.editPart(2,'unknown',{type:'translate',delta:[1,0,0]}),/失效/);
  s.select(2,1);assert.throws(()=>s.editPart(3,'unknown',{type:'translate',delta:[1,0,0]}),/先生成/);
  s.undo();assert.deepEqual(state(s),before);
});
check('invalid numeric values, inversion, too-small size, and huge extents reject atomically',()=>{
  const s=fresh(),before=state(s),p=part(s),b=structuredClone(p.bounds);
  const invalid=[
    {type:'push-pull',axis:0,side:1,distance:NaN},
    {type:'push-pull',axis:3,side:1,distance:1},
    {type:'push-pull',axis:0,side:0,distance:1},
    {type:'push-pull',axis:0,side:1,distance:'1'},
    {type:'push-pull',axis:0,side:1,distance:-999},
    {type:'translate',delta:[Infinity,0,0]},
    {type:'translate',delta:[1,2]},
    {type:'translate',delta:[1,'2',0]},
    {type:'translate',delta:[1e8,0,0]},
    {type:'set-bounds',bounds:[b[1],b[0]]},
    {type:'set-bounds',bounds:[[null,0,0],[1,1,1]]},
    {type:'set-bounds',bounds:[[0,0,0],[0.009,1,1]]},
    {type:'unknown'},null
  ];
  for(const edit of invalid){assert.throws(()=>s.editPart(2,p.partId,edit));assert.deepEqual(state(s),before);assert.equal(s.canUndo(),false);}
});
check('exact minimum size and allowed outer boundary accepted; one step beyond rejected',()=>{
  const s=fresh(),p=part(s),limits=s.getSourceSummary().editing.bounds;
  const bounds=[limits[0].slice(),limits[0].map(n=>n+0.01)];
  s.editPart(2,p.partId,{type:'set-bounds',bounds});
  close(s.getSelected(2).parts[0].bounds[1][0]-s.getSelected(2).parts[0].bounds[0][0],0.01);
  assert.throws(()=>s.editPart(2,p.partId,{type:'translate',delta:[-0.001,0,0]}),/超出/);
});
check('manual diagram retains changed-part highlight and old bounds',()=>{
  const s=fresh(),p=part(s);s.editPart(2,p.partId,{type:'push-pull',axis:2,side:1,distance:1});
  const diagram=s.getDiagram(2);assert.ok(diagram.highlightIds.includes(p.partId));
  assert.ok(diagram.outlines.some(b=>JSON.stringify(b)===JSON.stringify(p.bounds)));
  assert.match(diagram.title,/手动修改/);assert.match(diagram.evidence,/手动修改/);assert.match(diagram.reason,/待核对/);
});
check('multiple edited stages round-trip exactly and restored history starts empty',()=>{
  const s=fresh();s.editPart(2,part(s).partId,{type:'translate',delta:[1,0,0]});s.completeDraft();
  const p4=s.getSelected(4).parts[0];s.editPart(4,p4.partId,{type:'push-pull',axis:2,side:1,distance:0.5});s.completeDraft();
  const saved=JSON.parse(JSON.stringify(s.exportChoices())),restored=createMassingSession(model);
  assert.equal(saved.schema,'massing-editable-v5');assert.ok(saved.sourceFingerprint);
  assert.equal(saved[2].edits.length,1);assert.equal(saved[4].edits.length,1);
  restored.restoreChoices(saved);assert.deepEqual(state(restored),state(s));assert.equal(restored.canUndo(),false);
  saved[2].edits[0].edit.delta[0]=888;assert.deepEqual(state(restored),state(s));
});
check('v4 choices migrate with a visible source-binding warning',()=>{
  const old=fresh().exportChoices();old.schema='massing-source-grounded-v4';delete old.sourceFingerprint;
  const s=createMassingSession(model),result=s.restoreChoices(old);
  assert.equal(result.schema,'massing-editable-v5');assert.match(result.migrationWarning,/未绑定源模型/);
  assert.deepEqual(state(s),state(fresh()));
});
check('same envelope but different vertex data or file identity refuses saved edits',()=>{
  const mesh={id:'one',bounds:[[0,0,0],[20,20,20]],positions:[0,0,0,20,20,20,10,10,10]};
  const a={meshes:[mesh]},s=createMassingSession(a);s.completeDraft();
  s.editPart(2,s.getSelected(2).parts[0].partId,{type:'translate',delta:[1,0,0]});const saved=s.exportChoices();
  const altered=structuredClone(a);altered.meshes[0].positions[6]=11;
  const other=createMassingSession(altered);assert.throws(()=>other.restoreChoices(saved),/源模型/);
  assert.equal(other.getSelected(2),null);
  const tagged=createMassingSession({...a,sourceSha256:'other-file'});assert.throws(()=>tagged.restoreChoices(saved),/源模型/);
});
check('malformed restoration rejects locked-stage edits, corrupt values, missing chain, wrong source atomically',()=>{
  const s=fresh(),before=state(s),original=s.exportChoices();
  const bad=[];
  let v=structuredClone(original);v[1].edits=[{partId:'seed',edit:{type:'translate',delta:[1,0,0]}}];bad.push(v);
  v=structuredClone(original);v[6]={round:0,index:0};bad.push(v);
  v=structuredClone(original);delete v[2];bad.push(v);
  v=structuredClone(original);v[3].index='0';bad.push(v);
  v=structuredClone(original);v[3].edits=[{partId:'wrong',edit:{type:'translate',delta:[1,0,0]}}];bad.push(v);
  v=structuredClone(original);v[2].edits=[{partId:part(s).partId,edit:{type:'set-bounds',bounds:[[0,0,0],[0,0,0]]}}];bad.push(v);
  v=structuredClone(original);delete v.sourceFingerprint;bad.push(v);
  v=structuredClone(original);v.schema='massing-source-grounded-v4';v[2].edits=[{partId:part(s).partId,edit:{type:'translate',delta:[1,0,0]}}];bad.push(v);
  for(const saved of bad){assert.throws(()=>s.restoreChoices(saved));assert.deepEqual(state(s),before);}
});
check('a mass filling all allowed room still offers usable operations and round-trips',()=>{
  const s=fresh(),p=part(s);
  s.editPart(2,p.partId,{type:'set-bounds',bounds:s.getSourceSummary().editing.bounds});
  const choices=s.getCandidates(3);
  assert.equal(choices.length,2);
  assert.deepEqual(choices.map(c=>c.operation.type),['split','cut-corner']);
  assert.deepEqual(choices.map(c=>c.index),[0,1]);
  for(const c of choices)assert.notEqual(c.fingerprint,s.getSelected(2).fingerprint);
  assert.equal(s.completeDraft().added,3);
  const saved=s.exportChoices(),restored=createMassingSession(model);
  restored.restoreChoices(saved);assert.deepEqual(state(restored),state(s));
  s.undo();assert.equal(s.getSelected(3),null);s.redo();assert.deepEqual(state(restored),state(s));
});
check('exported selections and source candidate cannot mutate original geometry',()=>{
  const s=fresh(),source=s.getSelected(6),saved=s.exportChoices();
  source.parts[0].bounds[0][0]=9999;saved[2].index=999;
  assert.notEqual(s.getSelected(6).parts[0].bounds[0][0],9999);assert.equal(s.exportChoices()[2].index,0);
  assert.equal(JSON.stringify(model),sourceBefore);
});
console.log(JSON.stringify({passed:true,checks},null,2));
