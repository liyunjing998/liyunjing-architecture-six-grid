#!/usr/bin/env python3
"""Offline acceptance checks. Fixtures and copied workspaces live in TemporaryDirectory."""
import errno
import importlib.util
import json
import struct
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('intake', ROOT/'scripts/intake.py')
intake = importlib.util.module_from_spec(spec)
spec.loader.exec_module(intake)


def write_glb(path, compressed=False):
    positions = struct.pack('<9f', 0, 0, 0, 1, 0, 0, 0, 1, 0)
    data = {'asset': {'version': '2.0'}, 'scene': 0,
            'scenes': [{'nodes': [0], 'name': 'Fixture'}],
            'nodes': [{'mesh': 0, 'name': 'Source-only semantic clue'}],
            'meshes': [{'name': 'Test triangle', 'primitives': [{'attributes': {'POSITION': 0}}]}],
            'buffers': [{'byteLength': len(positions)}],
            'bufferViews': [{'buffer': 0, 'byteOffset': 0, 'byteLength': len(positions)}],
            'accessors': [{'bufferView': 0, 'componentType': 5126, 'count': 3, 'type': 'VEC3',
                           'min': [0, 0, 0], 'max': [1, 1, 0]}]}
    if compressed: data['extensionsRequired'] = ['KHR_draco_mesh_compression']
    encoded = json.dumps(data).encode('utf-8')
    encoded += b' ' * (-len(encoded) % 4)
    result = struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(encoded) + 8 + len(positions))
    result += struct.pack('<II', len(encoded), 0x4E4F534A) + encoded
    result += struct.pack('<II', len(positions), 0x004E4942) + positions
    path.write_bytes(result)
    return data


class IntakeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='massing-intake-test-')
        self.base = Path(self.temporary.name)
        self.inputs = self.base/'input'
        self.inputs.mkdir()

    def tearDown(self): self.temporary.cleanup()

    def test_empty_is_not_demo(self):
        report = intake.inspect(self.inputs)
        self.assertEqual(report['status'], 'NEED_MODEL')
        self.assertIsNone(report['selected'])

    def test_single_glb_keeps_source_and_clues(self):
        path = self.inputs/'建筑.glb'
        write_glb(path)
        before = path.read_bytes()
        report = intake.inspect(self.inputs)
        self.assertEqual(report['status'], 'READY_FOR_GEOMETRY_REVIEW')
        self.assertEqual(report['selected'], '建筑.glb')
        self.assertEqual(report['inspection']['source_node_hints'][0]['name'], 'Source-only semantic clue')
        self.assertEqual(path.read_bytes(), before)

    def test_glb_does_not_hide_other_building(self):
        write_glb(self.inputs/'A.glb')
        (self.inputs/'B.skp').write_bytes(b'native fixture')
        self.assertEqual(intake.inspect(self.inputs)['status'], 'NEED_SELECTION')

    def test_same_name_conversion_selects_glb(self):
        write_glb(self.inputs/'A.glb')
        (self.inputs/'A.skp').write_bytes(b'native fixture')
        report = intake.inspect(self.inputs)
        self.assertEqual(report['selected'], 'A.glb')

    def test_manifest_selects_different_named_conversion(self):
        write_glb(self.inputs/'mesh.glb')
        (self.inputs/'original.3dm').write_bytes(b'native fixture')
        (self.inputs/'model-manifest.json').write_text(json.dumps({'primary': 'mesh.glb', 'source_files': ['original.3dm']}))
        self.assertEqual(intake.inspect(self.inputs)['selected'], 'mesh.glb')

    def test_native_needs_conversion(self):
        for extension in ['.skp', '.3dm']:
            path = self.inputs/('A'+extension)
            path.write_bytes(b'native fixture')
            report = intake.inspect(self.inputs)
            self.assertEqual(report['status'], 'NEED_CONVERSION')
            self.assertFalse(report['inspection']['native_geometry_read'])
            path.unlink()

    def test_corrupt_and_compressed_glb_rejected(self):
        path = self.inputs/'bad.glb'
        path.write_bytes(b'not a glb')
        self.assertEqual(intake.inspect(self.inputs)['status'], 'INVALID_INPUT')
        write_glb(path, compressed=True)
        self.assertEqual(intake.inspect(self.inputs)['status'], 'NEED_UNCOMPRESSED_EXPORT')

    def test_gltf_missing_dependency(self):
        data = write_glb(self.base/'fixture.glb')
        data['buffers'][0]['uri'] = 'missing.bin'
        (self.inputs/'A.gltf').write_text(json.dumps(data))
        self.assertEqual(intake.inspect(self.inputs)['status'], 'MISSING_RESOURCES')

    def test_manifest_escape_rejected(self):
        write_glb(self.base/'outside.glb')
        (self.inputs/'model-manifest.json').write_text(json.dumps({'primary': '../outside.glb'}))
        self.assertEqual(intake.inspect(self.inputs)['status'], 'INVALID_MANIFEST')

    def test_prepare_copies_reopenable_workspace_without_server(self):
        source = self.inputs/'建筑.glb'
        write_glb(source)
        output = self.base/'workspace'
        report_path = self.base/'report.json'
        command = [sys.executable, str(ROOT/'scripts/intake.py'), '--input-dir', str(self.inputs),
                   '--report', str(report_path), '--prepare', str(output)]
        result = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        report = json.loads(report_path.read_text())
        self.assertEqual(report['status'], 'READY_FOR_GEOMETRY_REVIEW')
        self.assertTrue((output/'index.html').is_file())
        self.assertEqual((output/'data/imported/建筑.glb').read_bytes(), source.read_bytes())
        self.assertFalse((output/'server.log').exists())
        self.assertIn('launch.py', report['start_command_posix'])
        result = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(json.loads(result.stdout)['status'], 'PREPARE_REFUSED')

    def test_report_cannot_overwrite_input(self):
        write_glb(self.inputs/'A.glb')
        result = subprocess.run([sys.executable, str(ROOT/'scripts/intake.py'), '--input-dir', str(self.inputs),
                                 '--report', str(self.inputs/'oops.json')], capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.inputs/'oops.json').exists())

    def test_permission_denied_is_not_port_in_use(self):
        launcher_spec = importlib.util.spec_from_file_location('launch', ROOT/'massing-six-grid/scripts/launch.py')
        launcher = importlib.util.module_from_spec(launcher_spec)
        launcher_spec.loader.exec_module(launcher)
        class DeniedSocket:
            def bind(self, value): raise PermissionError(errno.EPERM, 'test permission denied')
            def close(self): pass
        with patch.object(sys, 'argv', ['launch.py', '--output', str(self.base/'denied')]), \
             patch.object(launcher.urllib.request, 'urlopen', side_effect=OSError('offline test')), \
             patch.object(launcher.socket, 'socket', return_value=DeniedSocket()):
            with self.assertRaises(SystemExit) as cm: launcher.main()
        self.assertIn('这不是端口占用', str(cm.exception))


if __name__ == '__main__': unittest.main(verbosity=2)
